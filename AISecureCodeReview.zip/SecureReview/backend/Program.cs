using System.Threading.RateLimiting;
using MongoDB.Driver;
using SecureReview.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.WebHost.ConfigureKestrel(o =>
{
    o.AddServerHeader = false;
    o.Limits.MaxRequestBodySize = 512 * 1024;   // code submissions are capped
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<IMongoClient>(_ =>
    new MongoClient(builder.Configuration.GetConnectionString("Mongo") ?? "mongodb://localhost:27017"));
builder.Services.AddSingleton<ReviewRepository>();
builder.Services.AddSingleton<CodeReviewEngine>();
builder.Services.AddSingleton<UrlScanner>();
builder.Services.AddScoped<ApiKeyFilter>();
builder.Services.AddHttpClient<AiRemediationService>(c => c.Timeout = TimeSpan.FromSeconds(90));

builder.Services.AddCors(o => o.AddPolicy("Frontend", p => p
    .WithOrigins(builder.Configuration.GetSection("Cors:Origins").Get<string[]>() ?? new[] { "http://localhost:5173" })
    .WithMethods("GET", "POST", "DELETE")
    .WithHeaders("Content-Type", "X-Api-Key")));

builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    o.AddFixedWindowLimiter("scan", c =>
    {
        c.PermitLimit = 20;
        c.Window = TimeSpan.FromMinutes(1);
        c.QueueLimit = 0;
    });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseExceptionHandler(a => a.Run(async ctx =>
    {
        ctx.Response.StatusCode = StatusCodes.Status500InternalServerError;
        await ctx.Response.WriteAsJsonAsync(new { error = "Unexpected server error." });
    }));
    app.UseHsts();
    app.UseHttpsRedirection();
}

app.Use(async (ctx, next) =>
{
    if (!ctx.Request.Path.StartsWithSegments("/swagger"))
    {
        var h = ctx.Response.Headers;
        h["X-Content-Type-Options"] = "nosniff";
        h["X-Frame-Options"] = "DENY";
        h["Referrer-Policy"] = "no-referrer";
        h["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'";
        h["Cache-Control"] = "no-store";
    }
    await next();
});

app.UseCors("Frontend");
app.UseRateLimiter();
app.MapControllers();

app.Run();
