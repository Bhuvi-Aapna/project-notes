using System.IO.Compression;
using SecureCodeAI.Api.Models;
using SecureCodeAI.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace SecureCodeAI.Api.Controllers;

[ApiController]
[Route("api/scans")]
public sealed class ScanController : ControllerBase
{
    private readonly SecurityScanner _scanner;
    private readonly ScanStore _store;
    private readonly AiRemediationService _ai;

    public ScanController(SecurityScanner scanner, ScanStore store, AiRemediationService ai)
    {
        _scanner = scanner;
        _store = store;
        _ai = ai;
    }

    [HttpPost("upload")]
    [RequestSizeLimit(50_000_000)]
    public async Task<ActionResult<ScanResult>> Upload(
        IFormFile file,
        CancellationToken cancellationToken)
    {
        if (file is null || file.Length == 0)
            return BadRequest("ZIP file is required.");

        if (!Path.GetExtension(file.FileName).Equals(".zip", StringComparison.OrdinalIgnoreCase))
            return BadRequest("Only ZIP files are supported.");

        var files = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        await using var input = file.OpenReadStream();
        using var archive = new ZipArchive(input, ZipArchiveMode.Read);

        foreach (var entry in archive.Entries)
        {
            if (entry.FullName.Contains("..", StringComparison.Ordinal) ||
                string.IsNullOrWhiteSpace(entry.Name))
                continue;

            var extension = Path.GetExtension(entry.Name);
            if (!extension.Equals(".cs", StringComparison.OrdinalIgnoreCase))
                continue;

            if (entry.Length > 2_000_000)
                continue;

            await using var stream = entry.Open();
            using var reader = new StreamReader(stream);
            files[entry.FullName.Replace('\\', '/')] =
                await reader.ReadToEndAsync(cancellationToken);
        }

        if (files.Count == 0)
            return BadRequest("No C# files were found in the ZIP.");

        var projectName = Path.GetFileNameWithoutExtension(file.FileName);
        var result = _scanner.Scan(projectName, files);
        _store.Save(result, files);

        return Ok(result);
    }

    [HttpGet]
    public ActionResult<IEnumerable<ScanResult>> GetAll() => Ok(_store.All());

    [HttpGet("{scanId}")]
    public ActionResult<ScanResult> Get(string scanId)
    {
        var result = _store.Get(scanId);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpPost("{scanId}/remediate/{findingId}")]
    public async Task<ActionResult<RemediationResult>> Remediate(
        string scanId,
        string findingId,
        CancellationToken cancellationToken)
    {
        var scan = _store.Get(scanId);
        if (scan is null)
            return NotFound("Scan not found.");

        var finding = scan.Findings.FirstOrDefault(x => x.Id == findingId);
        if (finding is null)
            return NotFound("Finding not found.");

        if (!_store.TryGetFile(scanId, finding.File, out var source))
            return NotFound("Source file is no longer available in the scan store.");

        try
        {
            var result = await _ai.GenerateAsync(finding, source, cancellationToken);

            // Validate the proposed full-file remediation with the same scanner.
            var validationFiles = new Dictionary<string, string>
            {
                [finding.File] = result.After
            };

            var validation = _scanner.Scan(scan.ProjectName, validationFiles);
            var sameRuleStillDetected = validation.Findings.Any(
                x => x.Rule.Equals(finding.Rule, StringComparison.OrdinalIgnoreCase));

            var validated = sameRuleStillDetected
                ? "Validation failed: the same rule is still detected after the proposed change."
                : "Validation passed for this rule: the same rule was not detected in the corrected file.";

            result = result with { Validation = $"{result.Validation} {validated}" };

            return Ok(result);
        }
        catch (Exception ex)
        {
            return Problem(
                title: "AI remediation failed",
                detail: ex.Message,
                statusCode: StatusCodes.Status502BadGateway);
        }
    }
}
