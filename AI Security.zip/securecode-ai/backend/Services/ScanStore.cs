using System.Collections.Concurrent;
using SecureCodeAI.Api.Models;

namespace SecureCodeAI.Api.Services;

public sealed class ScanStore
{
    private readonly ConcurrentDictionary<string, ScanResult> _scans = new();
    private readonly ConcurrentDictionary<string, Dictionary<string, string>> _files = new();

    public void Save(ScanResult result, Dictionary<string, string> files)
    {
        _scans[result.ScanId] = result;
        _files[result.ScanId] = files;
    }

    public ScanResult? Get(string id) =>
        _scans.TryGetValue(id, out var result) ? result : null;

    public bool TryGetFile(string scanId, string file, out string source)
    {
        source = "";
        if (!_files.TryGetValue(scanId, out var files))
            return false;

        return files.TryGetValue(file, out source!);
    }

    public IEnumerable<ScanResult> All() =>
        _scans.Values.OrderByDescending(x => x.CreatedAtUtc);
}
