using SecureCodeAI.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddCors(options =>
{
    options.AddPolicy("frontend", policy =>
    {
        policy.WithOrigins("http://localhost:5173")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

builder.Services.AddSingleton<ScanStore>();
builder.Services.AddSingleton<SecurityScanner>();
builder.Services.AddSingleton<AiRemediationService>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseCors("frontend");
app.MapGet("/health", () => Results.Ok(new { status = "ok", service = "SecureCodeAI.Api" }));
app.MapControllers();

app.Run("http://localhost:5080");
