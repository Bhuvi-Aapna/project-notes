using System.Net;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using SecureReview.Api.Models;

namespace SecureReview.Api.Services;

/// <summary>
/// Passive, non-destructive OWASP checks against a URL the caller is authorised to test.
/// The scanner itself is SSRF-hardened: only http/https, destination IPs are validated at connect time
/// (defeats DNS rebinding), redirects are never followed, and bodies are capped at 64 KB.
/// </summary>
public class UrlScanner
{
    private readonly bool _allowPrivate;
    private readonly ILogger<UrlScanner> _log;

    public UrlScanner(IConfiguration cfg, ILogger<UrlScanner> log)
    {
        _allowPrivate = cfg.GetValue<bool>("UrlScanner:AllowPrivateTargets");
        _log = log;
    }

    private sealed record Probe(string Path, string Aspect, Func<Snap, bool> Hit, string Sev, string Cwe, string Fix, bool Warn);

    private sealed record Snap(int Status, string? Location, Dictionary<string, string> H, List<string> SetCookies, string ContentType, string Body);

    public static bool TryParseTarget(string raw, out Uri uri, out string error)
    {
        error = "";
        uri = default!;
        if (!Uri.TryCreate(raw?.Trim(), UriKind.Absolute, out var u) || (u.Scheme != Uri.UriSchemeHttp && u.Scheme != Uri.UriSchemeHttps))
        { error = "Enter a full http:// or https:// URL."; return false; }
        if (!string.IsNullOrEmpty(u.UserInfo)) { error = "URLs with embedded credentials are not allowed."; return false; }
        uri = u;
        return true;
    }

    public static bool IsPrivate(IPAddress ip)
    {
        if (ip.IsIPv4MappedToIPv6) ip = ip.MapToIPv4();
        if (IPAddress.IsLoopback(ip)) return true;
        if (ip.AddressFamily == AddressFamily.InterNetworkV6)
        {
            var b6 = ip.GetAddressBytes();
            return ip.IsIPv6LinkLocal || ip.IsIPv6SiteLocal || ip.IsIPv6Multicast || (b6[0] & 0xFE) == 0xFC || ip.Equals(IPAddress.IPv6Any);
        }
        var b = ip.GetAddressBytes();
        return b[0] == 10 || b[0] == 0 ||
               (b[0] == 172 && b[1] >= 16 && b[1] <= 31) ||
               (b[0] == 192 && b[1] == 168) ||
               (b[0] == 169 && b[1] == 254) ||            // link-local + cloud metadata (169.254.169.254)
               (b[0] == 100 && b[1] >= 64 && b[1] <= 127) || // CGNAT
               b[0] >= 224;
    }

    public async Task<List<TestResult>> ScanAsync(Uri target, CancellationToken ct)
    {
        var res = new List<TestResult>();
        X509Certificate2? cert = null;
        var tlsErrors = SslPolicyErrors.None;

        using var handler = new SocketsHttpHandler
        {
            AllowAutoRedirect = false,
            UseCookies = false,
            AutomaticDecompression = DecompressionMethods.All,
            ConnectTimeout = TimeSpan.FromSeconds(8),
            ConnectCallback = async (ctx, token) =>
            {
                var ips = await Dns.GetHostAddressesAsync(ctx.DnsEndPoint.Host, token);
                var ok = ips.Where(ip => _allowPrivate || !IsPrivate(ip)).ToArray();
                if (ok.Length == 0)
                    throw new HttpRequestException("Scan blocked: the target resolves to a private or internal address.");
                var socket = new Socket(SocketType.Stream, ProtocolType.Tcp) { NoDelay = true };
                try
                {
                    await socket.ConnectAsync(ok, ctx.DnsEndPoint.Port, token);
                    return new NetworkStream(socket, ownsSocket: true);
                }
                catch { socket.Dispose(); throw; }
            },
            SslOptions = new SslClientAuthenticationOptions
            {
                EnabledSslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13,
                RemoteCertificateValidationCallback = (_, c, _, errors) =>
                {
                    tlsErrors = errors;
                    if (c is not null) cert = new X509Certificate2(c);
                    return errors == SslPolicyErrors.None;   // strict: never accept an invalid certificate
                }
            }
        };
        using var http = new HttpClient(handler, disposeHandler: false) { Timeout = TimeSpan.FromSeconds(12) };
        http.DefaultRequestHeaders.UserAgent.ParseAdd("SecureReview-Scanner/1.0 (defensive-assessment)");

        async Task<Snap> Send(HttpMethod method, Uri uri, string? origin = null)
        {
            using var req = new HttpRequestMessage(method, uri);
            if (origin is not null) req.Headers.TryAddWithoutValidation("Origin", origin);
            using var resp = await http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
            var h = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var kv in resp.Headers) h[kv.Key] = string.Join(", ", kv.Value);
            foreach (var kv in resp.Content.Headers) h[kv.Key] = string.Join(", ", kv.Value);
            var cookies = resp.Headers.TryGetValues("Set-Cookie", out var sc) ? sc.ToList() : new List<string>();
            var body = "";
            if (method != HttpMethod.Options && method != HttpMethod.Head)
            {
                await using var s = await resp.Content.ReadAsStreamAsync(ct);
                var buf = new byte[64 * 1024];
                var read = 0;
                int n;
                while (read < buf.Length && (n = await s.ReadAsync(buf.AsMemory(read, buf.Length - read), ct)) > 0) read += n;
                body = Encoding.UTF8.GetString(buf, 0, read);
            }
            return new Snap((int)resp.StatusCode, resp.Headers.Location?.ToString(), h, cookies,
                resp.Content.Headers.ContentType?.MediaType ?? "", body);
        }

        TestResult Mk(string id, string owasp, string aspect, string status, string sev, string? cwe, int? httpStatus,
            string desc, string? evidence = null, string? rec = null, string? fix = null) => new()
        {
            RuleId = id, Owasp = owasp, Aspect = aspect, Status = status, Severity = sev, Cwe = cwe,
            HttpStatus = httpStatus, Description = desc, Evidence = evidence, Recommendation = rec, FixedCode = fix
        };

        // ---- main request ----
        Snap m;
        try { m = await Send(HttpMethod.Get, target); }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or AuthenticationException)
        {
            if (tlsErrors != SslPolicyErrors.None)
                res.Add(Mk("U-02", "A02", "TLS certificate validity", "Fail", "Critical", "CWE-295", null,
                    "The server's TLS certificate failed validation, so clients cannot trust the connection.",
                    $"Validation errors: {tlsErrors}", "Install a valid certificate issued by a trusted CA that matches the host name.", Fixes.U_Https));
            else
                res.Add(Mk("U-00", "A05", "Target reachable", "Info", "Info", null, null,
                    "The target could not be scanned.", Truncate(ex.Message, 300)));
            return res;
        }

        var https = target.Scheme == Uri.UriSchemeHttps;
        var isHtml = m.ContentType.Contains("html", StringComparison.OrdinalIgnoreCase);
        var isJson = m.ContentType.Contains("json", StringComparison.OrdinalIgnoreCase);
        string? Hdr(string n) => m.H.TryGetValue(n, out var v) ? v : null;

        // A02 transport
        if (https)
            res.Add(Mk("U-01", "A02", "HTTPS in use", "Pass", "None", "CWE-319", m.Status, "The URL is served over HTTPS."));
        else if (m.Status is 301 or 302 or 307 or 308 && (m.Location ?? "").StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            res.Add(Mk("U-01", "A02", "HTTP redirects to HTTPS", "Pass", "None", "CWE-319", m.Status, "Plain HTTP is redirected to HTTPS."));
        else
            res.Add(Mk("U-01", "A02", "HTTPS enforced", "Fail", "High", "CWE-319", m.Status,
                "The endpoint answers over plain HTTP, so traffic can be read or altered in transit.",
                $"Scheme: http, HTTP {m.Status}", "Serve only HTTPS and redirect HTTP to HTTPS.", Fixes.U_Https));

        if (https && cert is not null)
        {
            var days = (cert.NotAfter - DateTime.Now).TotalDays;
            res.Add(days < 14
                ? Mk("U-02", "A02", "TLS certificate expiry", "Warning", "Medium", "CWE-324", m.Status,
                    "The certificate expires soon.", $"Expires {cert.NotAfter:yyyy-MM-dd} ({(int)days} days)", "Renew and automate renewal.")
                : Mk("U-02", "A02", "TLS certificate validity", "Pass", "None", "CWE-295", m.Status,
                    "Certificate chain and host name are valid.", $"Valid until {cert.NotAfter:yyyy-MM-dd}"));
        }

        if (https)
        {
            var hsts = Hdr("Strict-Transport-Security");
            if (hsts is null)
                res.Add(Mk("U-03", "A02", "Strict-Transport-Security (HSTS)", "Fail", "Medium", "CWE-319", m.Status,
                    "HSTS is missing, so browsers may still try HTTP first.", "Header absent", "Send HSTS with max-age of at least 6 months.", Fixes.U_Hsts));
            else
            {
                var age = Regex.Match(hsts, @"max-age=(\d+)", RegexOptions.IgnoreCase);
                var ok = age.Success && long.TryParse(age.Groups[1].Value, out var secs) && secs >= 15552000;
                res.Add(ok
                    ? Mk("U-03", "A02", "Strict-Transport-Security (HSTS)", "Pass", "None", "CWE-319", m.Status, "HSTS is present with a long max-age.", hsts)
                    : Mk("U-03", "A02", "Strict-Transport-Security (HSTS)", "Warning", "Low", "CWE-319", m.Status, "HSTS max-age is too short.", hsts, "Use at least 15552000 seconds.", Fixes.U_Hsts));
            }
        }

        // A05 headers
        var csp = Hdr("Content-Security-Policy");
        var weakSev = isHtml ? "Medium" : "Low";
        if (csp is null)
            res.Add(Mk("U-04", "A05", "Content-Security-Policy", "Fail", weakSev, "CWE-693", m.Status,
                "No CSP: injected scripts are not restricted by the browser.", "Header absent", "Add a restrictive CSP.", Fixes.U_Csp));
        else if (Regex.IsMatch(csp, "unsafe-inline|unsafe-eval"))
            res.Add(Mk("U-04", "A05", "Content-Security-Policy", "Warning", "Low", "CWE-693", m.Status,
                "CSP allows unsafe-inline or unsafe-eval, which weakens XSS protection.", Truncate(csp, 200), "Use nonces or hashes.", Fixes.U_Csp));
        else
            res.Add(Mk("U-04", "A05", "Content-Security-Policy", "Pass", "None", "CWE-693", m.Status, "A CSP is present.", Truncate(csp, 200)));

        res.Add(Hdr("X-Content-Type-Options")?.Contains("nosniff", StringComparison.OrdinalIgnoreCase) == true
            ? Mk("U-05", "A05", "X-Content-Type-Options", "Pass", "None", "CWE-693", m.Status, "nosniff is set.")
            : Mk("U-05", "A05", "X-Content-Type-Options", "Fail", "Low", "CWE-693", m.Status,
                "Browsers may MIME-sniff responses into executable types.", "Header absent", "Send X-Content-Type-Options: nosniff.", Fixes.U_Headers));

        var frameOk = Hdr("X-Frame-Options") is not null || (csp?.Contains("frame-ancestors", StringComparison.OrdinalIgnoreCase) ?? false);
        res.Add(frameOk
            ? Mk("U-06", "A05", "Clickjacking protection", "Pass", "None", "CWE-1021", m.Status, "Framing is restricted.")
            : Mk("U-06", "A05", "Clickjacking protection", "Fail", weakSev, "CWE-1021", m.Status,
                "The page can be embedded in another site's frame.", "No X-Frame-Options or frame-ancestors", "Send X-Frame-Options: DENY or CSP frame-ancestors.", Fixes.U_Headers));

        res.Add(Hdr("Referrer-Policy") is not null
            ? Mk("U-07", "A05", "Referrer-Policy", "Pass", "None", "CWE-200", m.Status, "A referrer policy is set.", Hdr("Referrer-Policy"))
            : Mk("U-07", "A05", "Referrer-Policy", "Fail", "Low", "CWE-200", m.Status,
                "Full URLs may leak to third parties through the Referer header.", "Header absent", "Set Referrer-Policy.", Fixes.U_Headers));

        res.Add(Hdr("Permissions-Policy") is not null
            ? Mk("U-08", "A05", "Permissions-Policy", "Pass", "None", "CWE-693", m.Status, "A permissions policy is set.")
            : Mk("U-08", "A05", "Permissions-Policy", "Info", "Info", "CWE-693", m.Status,
                "No Permissions-Policy header. Optional hardening for browser features.", "Header absent", null, Fixes.U_Headers));

        var leaks = new List<string>();
        foreach (var n in new[] { "X-Powered-By", "X-AspNet-Version", "X-AspNetMvc-Version" })
            if (Hdr(n) is { } v) leaks.Add($"{n}: {v}");
        if (Hdr("Server") is { } sv && Regex.IsMatch(sv, @"\d|/")) leaks.Add($"Server: {sv}");
        res.Add(leaks.Count == 0
            ? Mk("U-09", "A05", "Technology banner disclosure", "Pass", "None", "CWE-200", m.Status, "No version banners disclosed.")
            : Mk("U-09", "A05", "Technology banner disclosure", "Fail", "Low", "CWE-200", m.Status,
                "Response headers reveal the stack and versions, helping attackers pick exploits.", string.Join("; ", leaks), "Remove version headers.", Fixes.U_Banner));

        // A06 outdated components (header heuristics)
        var comp = string.Join(" ", new[] { Hdr("Server"), Hdr("X-Powered-By"), Hdr("X-AspNet-Version") }.Where(x => x is not null));
        if (Regex.IsMatch(comp, @"IIS/[1-9]\b|PHP/(?:[0-7]\.|8\.[01]\.)|Apache/2\.[0-3]\.|nginx/1\.(?:[0-9]|1[0-9])\.", RegexOptions.IgnoreCase) && comp.Length > 0)
            res.Add(Mk("U-10", "A06", "Outdated server component", "Fail", "High", "CWE-1104", m.Status,
                "A disclosed component version looks end-of-life. Heuristic: confirm on the server.", Truncate(comp, 200), "Upgrade to a supported release.", Fixes.U_Components));
        else if (comp.Length > 0)
            res.Add(Mk("U-10", "A06", "Outdated server component", "Pass", "None", "CWE-1104", m.Status, "Disclosed versions do not match known end-of-life patterns.", Truncate(comp, 200)));
        else
            res.Add(Mk("U-10", "A06", "Outdated server component", "Info", "Info", "CWE-1104", m.Status,
                "No versions disclosed. Component age cannot be judged from outside; use the code review on package files and run dependency scans."));

        // A01 CORS
        try
        {
            var probe = "https://untrusted.example";
            var c = await Send(HttpMethod.Get, target, probe);
            var acao = c.H.GetValueOrDefault("Access-Control-Allow-Origin");
            var acac = string.Equals(c.H.GetValueOrDefault("Access-Control-Allow-Credentials"), "true", StringComparison.OrdinalIgnoreCase);
            if (acao == probe)
                res.Add(Mk("U-11", "A01", "CORS origin validation", "Fail", acac ? "High" : "Medium", "CWE-942", c.Status,
                    "The server reflects an untrusted Origin" + (acac ? " and allows credentials, so any site can read authenticated responses." : "."),
                    $"Origin {probe} was echoed" + (acac ? " with credentials" : ""), "Allow-list exact origins.", Fixes.U_Cors));
            else if (acao == "*")
                res.Add(Mk("U-11", "A01", "CORS origin validation", "Warning", "Medium", "CWE-942", c.Status,
                    "Any origin may read responses. Fine for public data, unsafe for private APIs.", "Access-Control-Allow-Origin: *", "Restrict to your front-end origin.", Fixes.U_Cors));
            else
                res.Add(Mk("U-11", "A01", "CORS origin validation", "Pass", "None", "CWE-942", c.Status, "An untrusted origin was not allowed."));
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException) { }

        // A01 access control (unauthenticated access)
        if (m.Status is 401 or 403)
            res.Add(Mk("U-12", "A01", "Authentication required", "Pass", "None", "CWE-306", m.Status, "The endpoint rejects anonymous requests."));
        else if (m.Status == 200 && isJson)
            res.Add(Mk("U-12", "A01", "Anonymous access to data endpoint", "Warning", "Medium", "CWE-306", m.Status,
                "A JSON endpoint returned data without credentials. Confirm this is meant to be public.",
                "HTTP 200 application/json with no Authorization header", "Require authentication and authorisation.", Fixes.U_Auth));
        else
            res.Add(Mk("U-12", "A01", "Anonymous access", "Info", "Info", "CWE-306", m.Status,
                $"Anonymous request returned HTTP {m.Status}. Verify that unauthenticated access is intended."));

        // A07 cookies
        if (m.SetCookies.Count == 0)
            res.Add(Mk("U-13", "A07", "Session cookie flags", "Pass", "None", "CWE-614", m.Status, "No cookies were set on this response."));
        foreach (var raw in m.SetCookies.Take(10))
        {
            var name = raw.Split('=')[0].Trim();
            var missing = new List<string>();
            if (https && !Regex.IsMatch(raw, @"(^|;)\s*secure\b", RegexOptions.IgnoreCase)) missing.Add("Secure");
            if (!Regex.IsMatch(raw, @"(^|;)\s*httponly\b", RegexOptions.IgnoreCase)) missing.Add("HttpOnly");
            if (!Regex.IsMatch(raw, @"(^|;)\s*samesite=", RegexOptions.IgnoreCase)) missing.Add("SameSite");
            res.Add(missing.Count == 0
                ? Mk("U-13", "A07", $"Cookie flags: {name}", "Pass", "None", "CWE-614", m.Status, "Secure, HttpOnly and SameSite are set.", $"Cookie {name}")
                : Mk("U-13", "A07", $"Cookie flags: {name}", "Fail", "Medium", "CWE-614", m.Status,
                    "The cookie is missing protective flags, making theft or cross-site use easier.",
                    $"Cookie {name} missing: {string.Join(", ", missing)}", "Set all three flags.", Fixes.U_Cookie));
        }

        // A02 caching of API data
        if (isJson)
        {
            var cc = Hdr("Cache-Control") ?? "";
            res.Add(cc.Contains("no-store", StringComparison.OrdinalIgnoreCase)
                ? Mk("U-14", "A02", "Cache-Control on API response", "Pass", "None", "CWE-525", m.Status, "no-store is set.")
                : Mk("U-14", "A02", "Cache-Control on API response", "Warning", "Low", "CWE-525", m.Status,
                    "API data may be stored by browsers or proxies.", string.IsNullOrEmpty(cc) ? "Header absent" : cc, "Send Cache-Control: no-store for private data.", Fixes.U_Cache));
        }

        // A04 rate limiting
        var rl = m.H.Keys.Any(k => k.StartsWith("X-RateLimit", StringComparison.OrdinalIgnoreCase) ||
                                   k.StartsWith("RateLimit", StringComparison.OrdinalIgnoreCase) ||
                                   k.Equals("Retry-After", StringComparison.OrdinalIgnoreCase));
        res.Add(rl
            ? Mk("U-15", "A04", "Rate limiting signals", "Pass", "None", "CWE-770", m.Status, "Rate-limit headers were observed.")
            : Mk("U-15", "A04", "Rate limiting signals", "Info", "Info", "CWE-770", m.Status,
                "No rate-limit headers observed. This is not proof of absence; the scanner sends no bursts.", null, "Add rate limiting.", Fixes.U_RateLimit));

        // A05 error handling + A03 reflection/DB errors (harmless markers only)
        try
        {
            var bad = new Uri(target, "/securereview-probe-" + Guid.NewGuid().ToString("N")[..10]);
            var e = await Send(HttpMethod.Get, bad);
            var marker = Regex.Match(e.Body, @"System\.\w+Exception|Stack trace|   at [\w\.]+\(|Microsoft\.AspNetCore|Traceback \(most recent|Whitelabel Error Page|Server Error in '/'", RegexOptions.IgnoreCase);
            res.Add(marker.Success
                ? Mk("U-16", "A05", "Error page information leak", "Fail", "Medium", "CWE-209", e.Status,
                    "Error responses expose stack traces or framework details.", $"Matched marker: {Truncate(marker.Value.Trim(), 60)}", "Return generic errors.", Fixes.U_Error)
                : Mk("U-16", "A05", "Error page information leak", "Pass", "None", "CWE-209", e.Status, "A non-existent path returned no stack trace or framework details."));
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException) { }

        try
        {
            const string raw = "sr7x\"'<z>";
            var ub = new UriBuilder(target);
            var q = "securereview=" + Uri.EscapeDataString(raw);
            ub.Query = string.IsNullOrEmpty(target.Query) ? q : target.Query.TrimStart('?') + "&" + q;
            var r = await Send(HttpMethod.Get, ub.Uri);
            var reflectedHtml = r.ContentType.Contains("html", StringComparison.OrdinalIgnoreCase) && r.Body.Contains(raw);
            var dbErr = Regex.Match(r.Body, @"SqlException|You have an error in your SQL|ORA-\d{5}|Npgsql\.|MongoDB\.Driver|MongoCommandException|SQLSTATE\[", RegexOptions.IgnoreCase);
            res.Add(reflectedHtml
                ? Mk("U-17", "A03", "Reflected input encoding", "Fail", "High", "CWE-79", r.Status,
                    "A test marker containing quotes and angle brackets came back unencoded in HTML.", "Marker reflected raw", "Encode all output.", Fixes.U_Reflect)
                : Mk("U-17", "A03", "Reflected input encoding", "Pass", "None", "CWE-79", r.Status, "A marker with quotes and angle brackets was not reflected unencoded."));
            res.Add(dbErr.Success
                ? Mk("U-18", "A03", "Database error disclosure on special characters", "Fail", "High", "CWE-89", r.Status,
                    "Special characters triggered database error text, a sign input may reach a query unsafely.", $"Matched: {Truncate(dbErr.Value, 60)}", "Parameterise queries and hide driver errors.", Fixes.U_Reflect)
                : Mk("U-18", "A03", "Database error disclosure on special characters", "Pass", "None", "CWE-89", r.Status, "No database error text appeared."));
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException) { }

        // A05 exposed sensitive files
        var probes = new Probe[]
        {
            new Probe("/.env", "Exposed .env file", s => !s.ContentType.Contains("html") && Regex.IsMatch(s.Body, @"^\s*[A-Z][A-Z0-9_]*\s*=", RegexOptions.Multiline), "Critical", "CWE-538", Fixes.U_Files, false),
            new Probe("/.git/config", "Exposed .git repository", s => s.Body.Contains("[core]"), "Critical", "CWE-527", Fixes.U_Files, false),
            new Probe("/appsettings.json", "Exposed appsettings.json", s => Regex.IsMatch(s.Body, "\"(ConnectionStrings|Logging|AllowedHosts)\"", RegexOptions.IgnoreCase), "Critical", "CWE-538", Fixes.U_Files, false),
            new Probe("/swagger/index.html", "Public API documentation (Swagger)", s => s.Body.Contains("swagger", StringComparison.OrdinalIgnoreCase), "Low", "CWE-200", Fixes.U_Swagger, true),
        };
        foreach (var p in probes)
        {
            try
            {
                var s = await Send(HttpMethod.Get, new Uri(target, p.Path));
                var hit = s.Status == 200 && p.Hit(s);
                res.Add(hit
                    ? Mk("U-19", "A05", p.Aspect, p.Warn ? "Warning" : "Fail", p.Sev, p.Cwe, s.Status,
                        p.Warn ? "API documentation is reachable without authentication. Fine for a public API, risky otherwise." : "A sensitive file is downloadable from the web root.",
                        $"GET {p.Path} returned HTTP 200 (content not stored)", "Remove or protect it.", p.Fix)
                    : Mk("U-19", "A05", p.Aspect, "Pass", "None", p.Cwe, s.Status, $"{p.Path} is not exposed."));
            }
            catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException) { }
        }

        // A05 risky HTTP methods
        try
        {
            var o = await Send(HttpMethod.Options, target);
            var allow = o.H.GetValueOrDefault("Allow") ?? "";
            res.Add(Regex.IsMatch(allow, @"\bTRACE\b|\bTRACK\b", RegexOptions.IgnoreCase)
                ? Mk("U-20", "A05", "Risky HTTP methods", "Fail", "Medium", "CWE-693", o.Status,
                    "TRACE/TRACK is enabled and can aid cross-site tracing.", $"Allow: {allow}", "Disable TRACE.", Fixes.U_Methods)
                : Mk("U-20", "A05", "Risky HTTP methods", "Pass", "None", "CWE-693", o.Status, "TRACE/TRACK are not advertised."));
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException) { }

        // A08 external scripts without SRI
        if (isHtml)
        {
            var ext = Regex.Matches(m.Body, "<script(?![^>]*\\bintegrity=)[^>]*\\bsrc=[\"'](https?://[^\"']+)[\"']", RegexOptions.IgnoreCase)
                .Select(x => x.Groups[1].Value).Where(u => !u.Contains(target.Host, StringComparison.OrdinalIgnoreCase)).Distinct().Take(5).ToList();
            res.Add(ext.Count > 0
                ? Mk("U-21", "A08", "Third-party scripts without SRI", "Fail", "Low", "CWE-353", m.Status,
                    "External scripts load without integrity checks.", string.Join(", ", ext), "Add integrity + crossorigin.", Fixes.U_Sri)
                : Mk("U-21", "A08", "Third-party scripts without SRI", "Pass", "None", "CWE-353", m.Status, "No external scripts without integrity attributes."));
        }

        // Not testable from outside: shown for completeness
        res.Add(Mk("U-22", "A09", "Logging and monitoring", "Info", "Info", "CWE-778", null,
            "Logging and alerting cannot be verified from outside. Review server logs, alerts and the code review results."));
        res.Add(Mk("U-23", "A10", "Server-side request forgery", "Info", "Info", "CWE-918", null,
            "SSRF needs knowledge of outbound request features. Use the code review to find calls that use caller-supplied URLs."));

        _log.LogInformation("URL scan finished for {Host}: {Count} results", target.Host, res.Count);
        return res;
    }

    private static string Truncate(string s, int n) => s.Length <= n ? s : s[..n] + "…";
}
