# SecureReview: AI-Powered Secure Code Review and Vulnerability Remediation Engine

React + ASP.NET Core 8 + MongoDB. Review pasted code or scan a live API URL against the OWASP Top 10 (2021).
Every report lists each test with **OWASP category, test name, status, severity, code location or HTTP status, CWE**,
the vulnerable snippet, and a **secure code example** to paste in. Optional Claude-written fixes are added when an API key is set.

## Run it

```bash
# 1. MongoDB
docker compose up -d

# 2. API  (http://localhost:5080, Swagger at /swagger in Development)
cd backend
dotnet run
#   optional AI fixes:  set ANTHROPIC_API_KEY=<key>   (PowerShell: $env:ANTHROPIC_API_KEY="...")

# 3. UI   (http://localhost:5173)
cd frontend
npm install
npm run dev
```

Click **Load sample vulnerable code** in the UI for a one-click demo (about 25 findings).

## API

| Method | Route | Body | Purpose |
|---|---|---|---|
| POST | `/api/review/code` | `{ code, fileName?, useAi }` | Static OWASP review (42 rules) |
| POST | `/api/review/url` | `{ url, authorized: true, useAi }` | Passive scan of a URL you are allowed to test |
| GET | `/api/review?limit=30` | | History |
| GET | `/api/review/{id}` | | Full report |
| DELETE | `/api/review/{id}` | | Delete report |

Report shape: `score`, `grade`, `counts`, `categories[10]` (one per OWASP item), `results[]`
(`owasp, aspect, status Pass|Fail|Warning|Info, severity, line | httpStatus, cwe, code, evidence, recommendation, fixedCode, aiExplanation, aiFixedCode`).

## What is checked

**Code review** (C#, React/JS, `.csproj`, `package.json`, `appsettings.json`, HTML), regex rules in `Services/CodeReviewEngine.cs`:
A01 missing `[Authorize]`, open redirect, path traversal, CORS any origin. A02 MD5/SHA-1, DES/ECB, hard-coded secrets, `Random`, disabled TLS validation, HTTP URLs.
A03 SQL string building, MongoDB `$where`/`BsonDocument.Parse`, command execution, `Html.Raw`, `dangerouslySetInnerHTML`/`eval`.
A04 no rate limit on login, unrestricted upload. A05 dev exception page, no HTTPS/HSTS/security headers, Swagger, error leaks, XXE, CSRF off.
A06 vulnerable NuGet/npm versions (heuristic). A07 JWT validation off, hard-coded JWT key, weak policy, plaintext compare, cookie flags, token in localStorage, no lockout.
A08 BinaryFormatter / `TypeNameHandling`, scripts without SRI, dynamic assembly load. A09 sensitive data in logs, empty catch, no auth logging. A10 caller-controlled outbound URLs.

**URL scan** (`Services/UrlScanner.cs`): HTTPS and redirect, TLS certificate validity and expiry, HSTS, CSP, nosniff, clickjacking, Referrer-Policy,
Permissions-Policy, version banners, outdated-server heuristics, CORS origin reflection (probe origin only), anonymous access, cookie flags, cache headers,
rate-limit headers, error-page leaks, reflected-input encoding and DB error text (harmless marker), exposed `.env` / `.git` / `appsettings.json` / Swagger, TRACE method, third-party scripts without SRI.
A09 and A10 appear as "Info" because they cannot be verified from outside.

## Security of the tool itself

- URL scanner is SSRF-hardened: http/https only, destination IP validated at connect time (blocks loopback, RFC1918, link-local and cloud metadata, defeats DNS rebinding), no redirects followed, 64 KB body cap, TLS 1.2+ with strict certificate validation. Private targets are allowed only when `ASPNETCORE_ENVIRONMENT=Development` (so you can scan `http://localhost`).
- Caller must confirm authorisation for every URL scan. Cookie values and response bodies are never stored.
- Rate limiting (20 requests/min), 512 KB body cap, strict CORS, security headers, generic error responses, ObjectId validation, regex timeouts (ReDoS-safe), typed MongoDB access (no injection).
- Submitted code is treated as untrusted data in the AI prompt (prompt-injection guard).
- Optional `Security:ApiKey` + `X-Api-Key` guard for demos. **Production:** replace with Azure AD / JWT, move the Anthropic key to Key Vault, run behind HTTPS.

## Limits (be honest in your demo)

The code review is pattern-based static analysis. It finds common, high-signal issues fast but is not a full data-flow analyser, so expect some false positives (marked **Warning**) and misses.
The URL scan is passive and covers configuration, not business-logic flaws. Confirm results with `dotnet list package --vulnerable`, `npm audit`, and a full DAST tool such as OWASP ZAP before release.

## Add a rule

Add one `R(...)` line in `CodeReviewEngine.Rules` (id, OWASP id, title, severity, CWE, confidence, regex, description, recommendation, fix, optional `has:` / `not:`) and a snippet in `Fixes.cs`.
