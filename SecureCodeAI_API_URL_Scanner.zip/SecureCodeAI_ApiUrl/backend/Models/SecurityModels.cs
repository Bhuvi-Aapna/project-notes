namespace SecureCodeAI.Api.Models;

public enum Severity
{
    Low,
    Medium,
    High,
    Critical
}

public sealed record Finding
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N");
    public string Source { get; init; } = "Swagger";
    public string Rule { get; init; } = "";
    public string Title { get; init; } = "";
    public Severity Severity { get; init; }
    public string Cwe { get; init; } = "";
    public string Owasp { get; init; } = "";
    public string Endpoint { get; init; } = "";
    public string Method { get; init; } = "";
    public string Description { get; init; } = "";
    public string Evidence { get; init; } = "";
    public string Recommendation { get; init; } = "";
}

public sealed record ScanResult
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N");
    public string TargetUrl { get; init; } = "";
    public string SwaggerUrl { get; init; } = "";
    public DateTime CreatedAtUtc { get; init; } = DateTime.UtcNow;
    public int SecurityScore { get; init; }
    public int EndpointsAnalyzed { get; init; }
    public List<Finding> Findings { get; init; } = [];
    public Dictionary<string, int> SeverityCounts { get; init; } = [];
    public Dictionary<string, string> LiveChecks { get; init; } = [];
}
