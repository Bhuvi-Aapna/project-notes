using System.Text.RegularExpressions;
using SecureReview.Api.Models;

namespace SecureReview.Api.Services;

public sealed record Rule(
    string Id, string Owasp, string Title, string Severity, string Cwe, string Confidence,
    Regex Pattern, string Description, string Recommendation, string Fix,
    Regex? MustHave, Regex? MustNotHave);

/// <summary>Static OWASP Top 10 (2021) analysis for C#/.NET, React/JS, csproj, package.json and appsettings code.</summary>
public class CodeReviewEngine
{
    private const RegexOptions Opt = RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant;
    private static readonly TimeSpan Timeout = TimeSpan.FromSeconds(2); // protects this scanner from ReDoS

    private static Regex Rx(string p) => new(p, Opt, Timeout);

    private static Rule R(string id, string owasp, string title, string sev, string cwe, string conf,
        string pattern, string desc, string rec, string fix, string? has = null, string? not = null)
        => new(id, owasp, title, sev, cwe, conf, Rx(pattern), desc, rec, fix,
               has is null ? null : Rx(has), not is null ? null : Rx(not));

    public static readonly Rule[] Rules =
    [
        // ---------------- A01 Broken Access Control ----------------
        R("AC-001","A01","API controller has no authorization attribute","Medium","CWE-862","Medium",
          """\[ApiController\]""",
          "Controllers without [Authorize] are reachable by anonymous callers unless a global policy exists.",
          "Deny by default: add [Authorize] (or a global fallback policy) and opt out with [AllowAnonymous] only where needed.",
          Fixes.AC001, not: """\[Authorize|FallbackPolicy"""),
        R("AC-002","A01","Open redirect","Medium","CWE-601","Medium",
          """return\s+Redirect\(\s*(?!\x22|\$\x22)[A-Za-z_][\w\.\[\]]*\s*\)""",
          "Redirecting to a user-supplied URL lets attackers send victims to phishing sites.",
          "Validate with Url.IsLocalUrl or use LocalRedirect.", Fixes.AC002, not: """IsLocalUrl|LocalRedirect"""),
        R("AC-003","A01","Path traversal in file access","High","CWE-22","Medium",
          """File\.(ReadAll\w+|OpenRead|OpenWrite|Delete|WriteAll\w+)\(\s*(?:[A-Za-z_$]|\x22[^\x22\n]*\x22\s*\+)[^)]*\)""",
          "File paths built from request data can escape the intended folder with ../ sequences.",
          "Normalise with Path.GetFullPath, use Path.GetFileName on the name and verify the result stays inside the root.",
          Fixes.AC003, not: """GetFullPath|GetFileName"""),
        R("AC-004","A01","CORS allows any origin","Medium","CWE-942","High",
          """AllowAnyOrigin\s*\(\s*\)""",
          "Any website can call the API from a visitor's browser.",
          "Allow-list the exact front-end origins.", Fixes.AC004),

        // ---------------- A02 Cryptographic Failures ----------------
        R("CR-001","A02","Weak hash algorithm (MD5/SHA-1)","High","CWE-327","High",
          """\b(MD5|SHA1)(CryptoServiceProvider|Managed)?\.Create\s*\(|new\s+(MD5|SHA1)(CryptoServiceProvider|Managed)\s*\(|HashAlgorithm\.Create\(\s*[\x22'](MD5|SHA1)""",
          "MD5 and SHA-1 are broken for integrity and unsuitable for passwords.",
          "Use SHA-256+ for integrity and a slow password hasher (PBKDF2/BCrypt/Argon2) for passwords.", Fixes.CR001),
        R("CR-002","A02","Weak cipher or ECB mode","High","CWE-327","High",
          """\b(DES|TripleDES|RC2)(CryptoServiceProvider)?\.Create\s*\(|new\s+(DES|TripleDES|RC2)CryptoServiceProvider|CipherMode\.ECB""",
          "DES, 3DES, RC2 and ECB mode leak patterns and are deprecated.",
          "Use AES-GCM with a unique nonce per message.", Fixes.CR002),
        R("CR-003","A02","Hard-coded secret or credential","Critical","CWE-798","High",
          """(password|passwd|pwd|secret|api[_-]?key|apikey|accesskey|client[_-]?secret|connectionstring)\w*["']?\s*[:=]\s*["'][^"'\s]{4,}["']|(?:Password|Pwd)\s*=\s*[^;"'\s]{3,}\s*;|mongodb(\+srv)?://[^/\s:"']+:[^@\s"']+@""",
          "Secrets in source code leak through repositories, builds and screenshots.",
          "Move secrets to Key Vault / user-secrets / environment variables and rotate anything committed.", Fixes.CR003),
        R("CR-004","A02","Predictable random number generator","Medium","CWE-338","Medium",
          """new\s+Random\s*\(""",
          "System.Random is predictable. If it generates tokens, codes or IDs, they can be guessed.",
          "Use RandomNumberGenerator for anything security related.", Fixes.CR004),
        R("CR-005","A02","TLS certificate validation disabled","High","CWE-295","High",
          """DangerousAcceptAnyServerCertificateValidator|ServerCertificateValidationCallback\s*\+?=\s*[^;]*(=>\s*true|delegate[^}]*return\s+true)|ServerCertificateCustomValidationCallback\s*=\s*[^;]*=>\s*true""",
          "Accepting every certificate enables man-in-the-middle attacks.",
          "Remove the callback; trust a private CA explicitly if needed.", Fixes.CR005),
        R("CR-006","A02","Plain HTTP endpoint","Low","CWE-319","Medium",
          """\x22http://(?!localhost|127\.0\.0\.1|0\.0\.0\.0|schemas\.|www\.w3\.org)[^\x22\s]+\x22""",
          "Traffic over HTTP can be read or modified in transit.",
          "Use HTTPS URLs and enforce HTTPS + HSTS.", Fixes.CR006),

        // ---------------- A03 Injection ----------------
        R("IN-001","A03","SQL injection (string-built query)","Critical","CWE-89","High",
          """(SqlCommand|SqlDataAdapter|OleDbCommand|MySqlCommand|NpgsqlCommand|FromSqlRaw|ExecuteSqlRaw(Async)?)\s*\(\s*(\$@?\x22|@?\x22[^\x22\n]*\x22\s*\+)|CommandText\s*=\s*(\$@?\x22|@?\x22[^\x22\n]*\x22\s*\+)|\x22\s*(SELECT|INSERT|UPDATE|DELETE)\b[^\x22\n]*\x22\s*\+\s*[A-Za-z_]""",
          "User input concatenated into SQL lets attackers read, change or delete data.",
          "Use parameterised queries or EF Core interpolated APIs (FromSqlInterpolated).", Fixes.IN001),
        R("IN-002","A03","NoSQL (MongoDB) injection","High","CWE-943","High",
          """BsonDocument\.Parse\(\s*[^"\s)]|["']?\$where["']?|BsonJavaScript\s*\(""",
          "Query documents or JavaScript built from request data allow operator injection such as {\"$ne\": null}.",
          "Build filters with typed Builders<T>.Filter and bind input to typed DTOs.", Fixes.IN002),
        R("IN-003","A03","OS command execution","High","CWE-78","Medium",
          """Process\.Start\s*\(|new\s+ProcessStartInfo\s*\(""",
          "Spawning processes with request data enables command injection.",
          "Avoid shells, use ArgumentList and a strict allow-list.", Fixes.IN003),
        R("IN-004","A03","Unencoded HTML output (server)","Medium","CWE-79","Medium",
          """Html\.Raw\s*\(|\.InnerHtml\s*=|Response\.Write\s*\(\s*[^"\s]""",
          "Writing unencoded input into a page allows cross-site scripting.",
          "Rely on Razor encoding or sanitise with HtmlSanitizer.", Fixes.IN004),
        R("IN-005","A03","Dangerous DOM sink (React/JS)","High","CWE-79","Medium",
          """dangerouslySetInnerHTML|\.innerHTML\s*=|document\.write\s*\(|\beval\s*\(|new\s+Function\s*\(|insertAdjacentHTML""",
          "These APIs execute or render attacker-controlled markup and script.",
          "Render text through JSX or sanitise with DOMPurify.", Fixes.IN005),

        // ---------------- A04 Insecure Design ----------------
        R("DS-001","A04","No rate limiting on authentication endpoint","Medium","CWE-307","Medium",
          """public\s+(?:async\s+)?(?:Task<)?\w+>?\s+(?:Login|SignIn|Authenticate|ResetPassword|ForgotPassword)\w*\s*\(""",
          "Unthrottled login and reset endpoints invite brute force and credential stuffing.",
          "Add ASP.NET Core rate limiting and account lockout.", Fixes.DS001,
          has: """\[ApiController\]|ControllerBase""", not: """EnableRateLimiting|RateLimiter|AspNetCoreRateLimit"""),
        R("DS-002","A04","File upload without validation","Medium","CWE-434","Medium",
          """IFormFile\b""",
          "Uploads without type and size checks allow malware, oversized files and web shells.",
          "Allow-list extensions, cap size, rename files and store outside the web root.", Fixes.DS002,
          not: """GetExtension|AllowedExtensions|ContentType"""),

        // ---------------- A05 Security Misconfiguration ----------------
        R("MC-001","A05","Developer exception page not limited to development","Medium","CWE-215","High",
          """UseDeveloperExceptionPage\s*\(""",
          "Stack traces and configuration details are exposed to every visitor.",
          "Enable it only when IsDevelopment().", Fixes.MC001, not: """IsDevelopment\s*\("""),
        R("MC-002","A05","HTTPS redirection not configured","Medium","CWE-319","Medium",
          """WebApplication\.CreateBuilder|CreateDefaultBuilder""",
          "Without UseHttpsRedirection, clients can keep using plain HTTP.",
          "Call app.UseHttpsRedirection() (or enforce HTTPS at the gateway).", Fixes.MC002, not: """UseHttpsRedirection"""),
        R("MC-003","A05","HSTS not configured","Low","CWE-319","Medium",
          """WebApplication\.CreateBuilder|CreateDefaultBuilder""",
          "Browsers are not told to insist on HTTPS, leaving downgrade attacks possible.",
          "Enable HSTS in production.", Fixes.MC003, not: """UseHsts|Strict-Transport-Security"""),
        R("MC-004","A05","Swagger exposed outside development","Low","CWE-200","Medium",
          """UseSwagger\s*\(""",
          "Public API documentation maps your attack surface for outsiders.",
          "Expose Swagger only in Development or behind authentication.", Fixes.MC004, not: """IsDevelopment\s*\("""),
        R("MC-005","A05","Exception details returned to client","Medium","CWE-209","High",
          """return\s+(?:Ok|BadRequest|StatusCode|Problem|Content|NotFound)\s*\([^;]*\b(?:ex|e|exception)\.(?:Message|StackTrace|ToString\s*\(\s*\)|InnerException)""",
          "Internal error text reveals paths, queries and library versions.",
          "Log the exception, return a generic problem response.", Fixes.MC005),
        R("MC-006","A05","XML external entity (XXE) exposure","Medium","CWE-611","Medium",
          """new\s+XmlDocument\s*\(|DtdProcessing\s*=\s*DtdProcessing\.Parse|XmlResolver\s*=\s*new\s+XmlUrlResolver|new\s+XmlTextReader\s*\(""",
          "Parsing untrusted XML with DTD or external resolvers can read local files or call internal URLs.",
          "Prohibit DTDs and set XmlResolver to null.", Fixes.MC006, not: """XmlResolver\s*=\s*null"""),
        R("MC-007","A05","Security headers middleware missing","Low","CWE-693","Medium",
          """WebApplication\.CreateBuilder|CreateDefaultBuilder""",
          "No X-Content-Type-Options, CSP, X-Frame-Options or Referrer-Policy headers were found.",
          "Add a headers middleware (or a gateway rule).", Fixes.MC007, not: """X-Content-Type-Options|NWebsec|SecurityHeaders"""),
        R("MC-008","A05","Anti-forgery validation disabled","Medium","CWE-352","Medium",
          """\[IgnoreAntiforgeryToken""",
          "Cookie-authenticated state-changing actions become vulnerable to CSRF.",
          "Keep antiforgery validation, or use bearer tokens only.", Fixes.MC008),
        R("MC-009","A05","Risky configuration values","Low","CWE-16","Medium",
          """\x22Default\x22\s*:\s*\x22(Debug|Trace)\x22|\x22DetailedErrors\x22\s*:\s*true|\x22AllowedHosts\x22\s*:\s*\x22\*\x22""",
          "Debug logging, detailed errors or wildcard hosts widen the attack surface in production.",
          "Use Information level, disable DetailedErrors and list real host names.", Fixes.MC009),

        // ---------------- A06 Vulnerable and Outdated Components ----------------
        R("VC-001","A06","Known-vulnerable NuGet package version","Medium","CWE-1104","Medium",
          """<PackageReference\s+Include=\x22Newtonsoft\.Json\x22\s+Version=\x22(?:[0-9]|1[0-2])\.[^\x22]*\x22|<PackageReference\s+Include=\x22log4net\x22\s+Version=\x22(?:1\.|2\.0\.[0-9]\b)[^\x22]*\x22|<PackageReference\s+Include=\x22System\.Data\.SqlClient\x22""",
          "Heuristic match against packages with published advisories or end-of-support. Confirm with a real advisory scan.",
          "Upgrade and scan continuously.", Fixes.VC001, has: """<PackageReference"""),
        R("VC-002","A06","Known-vulnerable npm package version","Medium","CWE-1104","Medium",
          """\x22lodash\x22\s*:\s*\x22[\^~]?4\.(?:[0-9]|1[0-6])\.\d+\x22|\x22lodash\x22\s*:\s*\x22[\^~]?4\.17\.(?:[0-9]|1[0-9]|20)\x22|\x22axios\x22\s*:\s*\x22[\^~]?0\.\d+\.\d+\x22""",
          "Heuristic match against lodash < 4.17.21 and axios 0.x, both with published advisories.",
          "Run npm audit and upgrade.", Fixes.VC002, has: """\x22(dependencies|devDependencies)\x22"""),

        // ---------------- A07 Identification and Authentication Failures ----------------
        R("AU-001","A07","JWT validation disabled","High","CWE-347","High",
          """Validate(Issuer|Audience|Lifetime|IssuerSigningKey)\s*=\s*false|RequireSignedTokens\s*=\s*false|RequireExpirationTime\s*=\s*false""",
          "Tokens with the wrong issuer, audience, signature or expiry are accepted.",
          "Enable every validation flag.", Fixes.AU001),
        R("AU-002","A07","Hard-coded JWT signing key","Critical","CWE-798","High",
          """SymmetricSecurityKey\s*\(\s*[\w\.]*Encoding\.\w+\.GetBytes\s*\(\s*\x22[^\x22]+\x22\s*\)""",
          "Anyone with the source can forge valid tokens.",
          "Load a long random key from Key Vault or environment.", Fixes.AU002),
        R("AU-003","A07","Weak password policy","Medium","CWE-521","Medium",
          """RequiredLength\s*=\s*[1-7]\b|RequireDigit\s*=\s*false""",
          "Short passwords without complexity are easy to guess.",
          "Require 12+ characters and enable lockout.", Fixes.AU003),
        R("AU-004","A07","Plain-text password comparison","High","CWE-256","High",
          """\b\w+\.Password\s*==\s*\w+|\bpassword\s*==\s*\w+\.Password|\.Password\s*\.Equals\(""",
          "Passwords stored or compared in clear text are exposed in any data leak.",
          "Store salted hashes and verify with PasswordHasher.", Fixes.AU004),
        R("AU-005","A07","Insecure cookie flags","Medium","CWE-614","High",
          """HttpOnly\s*=\s*false|\bSecure\s*=\s*false|SecurePolicy\s*=\s*CookieSecurePolicy\.None|SameSite\s*=\s*SameSiteMode\.None""",
          "Cookies can be stolen by scripts, sent over HTTP or attached to cross-site requests.",
          "Set HttpOnly, Secure and SameSite=Strict/Lax.", Fixes.AU005),
        R("AU-006","A07","Token stored in browser storage","Medium","CWE-922","Medium",
          """(localStorage|sessionStorage)\.setItem\(\s*["'`](?:\w*token\w*|\w*jwt\w*|\w*auth\w*)["'`]""",
          "Any XSS on the page can read tokens from localStorage and take over the account.",
          "Use HttpOnly cookies or keep the token in memory.", Fixes.AU006),
        R("AU-007","A07","Account lockout disabled","Medium","CWE-307","High",
          """lockoutOnFailure\s*:\s*false""",
          "Unlimited password guesses against an account.",
          "Enable lockoutOnFailure and configure lockout options.", Fixes.AU007),

        // ---------------- A08 Software and Data Integrity Failures ----------------
        R("SI-001","A08","Insecure deserialization","Critical","CWE-502","High",
          """BinaryFormatter|NetDataContractSerializer|SoapFormatter|LosFormatter|ObjectStateFormatter|TypeNameHandling\s*=\s*[\w\.]*TypeNameHandling\.(?:All|Auto|Objects|Arrays)|SimpleTypeResolver""",
          "Deserialising attacker-controlled data with polymorphic type handling can lead to remote code execution.",
          "Use System.Text.Json with typed models.", Fixes.SI001),
        R("SI-002","A08","External script without Subresource Integrity","Low","CWE-353","Medium",
          """<script(?![^>]*\bintegrity=)[^>]*\bsrc=["']https?://[^"']+["']""",
          "A compromised CDN would run arbitrary code on your pages.",
          "Add integrity and crossorigin, or bundle the dependency.", Fixes.SI002, has: """<script"""),
        R("SI-003","A08","Dynamic assembly loading","Medium","CWE-829","Medium",
          """Assembly\.(Load|LoadFrom|LoadFile)\s*\(\s*[A-Za-z_$]""",
          "Loading code by a variable name can execute untrusted binaries.",
          "Allow-list plug-ins and verify signatures.", Fixes.SI003, not: """AllowedPlugins|allowed\.Contains"""),

        // ---------------- A09 Security Logging and Monitoring Failures ----------------
        R("LG-001","A09","Sensitive data written to logs","Medium","CWE-532","High",
          """(?:logger\.\w+|Log\.\w+|Console\.Write(?:Line)?|Debug\.Write(?:Line)?|console\.(?:log|info|debug))\s*\([^;\n]*\b(?:password|passwd|secret|token|apikey|api_key|creditcard|cardnumber|ssn)\b""",
          "Credentials in logs are readable by everyone with log access.",
          "Log identifiers only.", Fixes.LG001),
        R("LG-002","A09","Swallowed exception","Low","CWE-390","Medium",
          """catch\s*(?:\([^)]*\))?\s*\{\s*(?://[^\n]*)?\s*\}""",
          "Silent catch blocks hide failures and attacks.",
          "Log and rethrow, or handle deliberately.", Fixes.LG002),
        R("LG-003","A09","Authentication events not logged","Low","CWE-778","Medium",
          """public\s+(?:async\s+)?(?:Task<)?\w+>?\s+(?:Login|SignIn|Authenticate)\w*\s*\(""",
          "Without login success/failure logs, brute force and account takeover go unnoticed.",
          "Log auth events and alert on anomalies.", Fixes.LG003,
          not: """ILogger|_logger|\.Log(?:Information|Warning|Error)"""),

        // ---------------- A10 SSRF ----------------
        R("SR-001","A10","Server-side request with caller-controlled URL","High","CWE-918","Medium",
          """\.(?:GetAsync|GetStringAsync|GetStreamAsync|GetByteArrayAsync|PostAsync|PutAsync|DeleteAsync)\s*\(\s*(?:\$@?\x22|[A-Za-z_][\w\.\[\]]*\s*[,)])|WebRequest\.Create\s*\(\s*[A-Za-z_$]|\.Download(?:String|File|Data)(?:Async)?\s*\(\s*[A-Za-z_$]""",
          "If the URL comes from a request, attackers can make your server reach internal services or cloud metadata.",
          "Allow-list hosts, require HTTPS, block private IP ranges and disable redirects.", Fixes.SR001,
          not: """AllowedHosts|Allowlist|AllowList|IsPrivate|IsLoopback"""),
    ];

    public List<TestResult> Review(string code)
    {
        var results = new List<TestResult>();
        var lines = code.Split('\n');
        var starts = new int[lines.Length];
        for (int i = 1, pos = 0; i < lines.Length; i++) { pos += lines[i - 1].Length + 1; starts[i] = pos; }

        int LineOf(int index)
        {
            var idx = Array.BinarySearch(starts, index);
            return (idx >= 0 ? idx : ~idx - 1) + 1;
        }

        foreach (var rule in Rules)
        {
            try
            {
                if (rule.MustHave is not null && !rule.MustHave.IsMatch(code)) continue; // not applicable

                var matches = rule.Pattern.Matches(code).Cast<Match>().ToList();
                var absenceRule = rule.MustNotHave is not null;

                if (absenceRule)
                {
                    if (matches.Count == 0) continue; // anchor not present -> not applicable
                    if (rule.MustNotHave!.IsMatch(code))
                    {
                        results.Add(Make(rule, "Pass", "None", "Required control found in the submitted code."));
                        continue;
                    }
                    matches = matches.Take(1).ToList();
                }

                if (matches.Count == 0)
                {
                    results.Add(Make(rule, "Pass", "None", "No occurrences of this pattern found."));
                    continue;
                }

                foreach (var m in matches.Take(10))
                {
                    var line = LineOf(m.Index);
                    var snippet = lines[line - 1].Trim();
                    if (snippet.Length > 220) snippet = snippet[..220] + "…";
                    var r = Make(rule, rule.Confidence == "High" ? "Fail" : "Warning", rule.Severity, rule.Description);
                    r.Line = line;
                    r.Code = snippet;
                    r.Recommendation = rule.Recommendation;
                    r.FixedCode = rule.Fix;
                    results.Add(r);
                }
            }
            catch (RegexMatchTimeoutException)
            {
                results.Add(Make(rule, "Info", "Info", "Rule skipped: input was too complex to analyse in time."));
            }
        }
        return results;
    }

    private static TestResult Make(Rule rule, string status, string severity, string description) => new()
    {
        RuleId = rule.Id,
        Owasp = rule.Owasp,
        Aspect = rule.Title,
        Status = status,
        Severity = severity,
        Cwe = rule.Cwe,
        Description = description
    };
}
