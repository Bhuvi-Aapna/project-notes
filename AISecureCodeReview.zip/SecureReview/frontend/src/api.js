const BASE = import.meta.env.VITE_API_URL || "";
// A key bundled into a browser app is visible to every user. Use it for demos only;
// in production put Azure AD / JWT sign-in in front of the API.
const KEY = import.meta.env.VITE_API_KEY || "";

async function call(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(KEY ? { "X-Api-Key": KEY } : {}),
    },
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg =
      data.error ||
      (res.status === 429 ? "Too many requests. Wait a minute and try again." : null) ||
      (data.errors && Object.values(data.errors).flat()[0]) ||
      `Request failed (HTTP ${res.status}).`;
    throw new Error(msg);
  }
  return data;
}

export const api = {
  capabilities: () => call("/api/review/capabilities"),
  history: () => call("/api/review?limit=30"),
  get: (id) => call(`/api/review/${id}`),
  remove: (id) => call(`/api/review/${id}`, { method: "DELETE" }),
  reviewCode: (body) => call("/api/review/code", { method: "POST", body: JSON.stringify(body) }),
  reviewUrl: (body) => call("/api/review/url", { method: "POST", body: JSON.stringify(body) }),
};
