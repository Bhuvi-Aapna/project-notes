using MongoDB.Bson;
using MongoDB.Driver;
using SecureReview.Api.Models;

namespace SecureReview.Api.Services;

public class ReviewRepository
{
    private readonly IMongoCollection<ReviewReport> _col;

    public ReviewRepository(IMongoClient client, IConfiguration cfg, ILogger<ReviewRepository> log)
    {
        var db = client.GetDatabase(cfg["Mongo:Database"] ?? "securereview");
        _col = db.GetCollection<ReviewReport>("reports");
        try
        {
            _col.Indexes.CreateOne(new CreateIndexModel<ReviewReport>(
                Builders<ReviewReport>.IndexKeys.Descending(r => r.CreatedAt)));
        }
        catch (Exception ex) { log.LogWarning(ex, "Could not create MongoDB index (is MongoDB running?)"); }
    }

    public async Task InsertAsync(ReviewReport report, CancellationToken ct) =>
        await _col.InsertOneAsync(report, cancellationToken: ct);

    public async Task<ReviewReport?> GetAsync(string id, CancellationToken ct)
    {
        if (!ObjectId.TryParse(id, out _)) return null;      // reject anything that is not an ObjectId
        return await _col.Find(r => r.Id == id).FirstOrDefaultAsync(ct);
    }

    public async Task<List<ReportListItem>> ListAsync(int limit, CancellationToken ct) =>
        await _col.Find(FilterDefinition<ReviewReport>.Empty)
            .SortByDescending(r => r.CreatedAt)
            .Limit(Math.Clamp(limit, 1, 100))
            .Project(r => new ReportListItem
            {
                Id = r.Id, Type = r.Type, Target = r.Target, CreatedAt = r.CreatedAt,
                Score = r.Score, Grade = r.Grade, Counts = r.Counts
            })
            .ToListAsync(ct);

    public async Task<bool> DeleteAsync(string id, CancellationToken ct)
    {
        if (!ObjectId.TryParse(id, out _)) return false;
        var res = await _col.DeleteOneAsync(r => r.Id == id, ct);
        return res.DeletedCount > 0;
    }
}
