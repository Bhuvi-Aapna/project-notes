using System.ComponentModel.DataAnnotations;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SecureReview.Api.Models;

/// <summary>One executed security test (rule) and its outcome.</summary>
public class TestResult
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
    public string RuleId { get; set; } = "";
    public string Owasp { get; set; } = "";          // A01..A10
    public string OwaspName { get; set; } = "";
    public string Aspect { get; set; } = "";         // what was tested
    public string Status { get; set; } = "Pass";     // Pass | Fail | Warning | Info
    public string Severity { get; set; } = "None";   // Critical | High | Medium | Low | Info | None
    public string? Cwe { get; set; }
    public int? Line { get; set; }                   // code review
    public int? HttpStatus { get; set; }             // URL scan
    public string? Code { get; set; }                // offending snippet
    public string? Evidence { get; set; }            // URL scan evidence (never raw bodies/cookie values)
    public string Description { get; set; } = "";
    public string? Recommendation { get; set; }
    public string? FixedCode { get; set; }           // rule-based secure example
    public string? AiExplanation { get; set; }       // optional, Claude
    public string? AiFixedCode { get; set; }         // optional, Claude
}

public class CategorySummary
{
    public string Owasp { get; set; } = "";
    public string Name { get; set; } = "";
    public string Status { get; set; } = "NotTested"; // Fail | Warning | Pass | NotTested
    public int Tests { get; set; }
    public int Passed { get; set; }
    public int Failed { get; set; }
    public int Warnings { get; set; }
}

public class SeverityCounts
{
    public int Critical { get; set; }
    public int High { get; set; }
    public int Medium { get; set; }
    public int Low { get; set; }
    public int Info { get; set; }
}

public class ReviewReport
{
    [BsonId, BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }
    public string Type { get; set; } = "Code";       // Code | Url
    public string Target { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public int Score { get; set; }
    public string Grade { get; set; } = "A";
    public string Summary { get; set; } = "";
    public bool AiUsed { get; set; }
    public SeverityCounts Counts { get; set; } = new();
    public List<CategorySummary> Categories { get; set; } = new();
    public List<TestResult> Results { get; set; } = new();
}

public class ReportListItem
{
    public string? Id { get; set; }
    public string Type { get; set; } = "";
    public string Target { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public int Score { get; set; }
    public string Grade { get; set; } = "";
    public SeverityCounts Counts { get; set; } = new();
}

public class CodeReviewRequest
{
    [Required, MinLength(10), MaxLength(200_000)]
    public string Code { get; set; } = "";
    [MaxLength(260)]
    public string? FileName { get; set; }
    public bool UseAi { get; set; }
}

public class UrlReviewRequest
{
    [Required, MaxLength(2048)]
    public string Url { get; set; } = "";
    /// <summary>The caller confirms they own or are authorised to test the target.</summary>
    public bool Authorized { get; set; }
    public bool UseAi { get; set; }
}

public static class OwaspCatalog
{
    public static readonly (string Id, string Name)[] Top10 = new[]
    {
        ("A01", "Broken Access Control"),
        ("A02", "Cryptographic Failures"),
        ("A03", "Injection"),
        ("A04", "Insecure Design"),
        ("A05", "Security Misconfiguration"),
        ("A06", "Vulnerable and Outdated Components"),
        ("A07", "Identification and Authentication Failures"),
        ("A08", "Software and Data Integrity Failures"),
        ("A09", "Security Logging and Monitoring Failures"),
        ("A10", "Server-Side Request Forgery (SSRF)"),
    };

    public static string NameOf(string id) => Top10.First(x => x.Id == id).Name;
}
