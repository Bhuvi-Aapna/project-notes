import { useEffect, useMemo, useState } from "react";
import { api } from "./api.js";
import sampleCode from "./sample.cs?raw";

const SEVERITIES = ["Critical", "High", "Medium", "Low", "Info"];
const STATUSES = ["Fail", "Warning", "Pass", "Info"];

function Pill({ kind, children }) {
  return <span className={`pill ${kind}`}>{children}</span>;
}

function CodeBlock({ title, text }) {
  const [copied, setCopied] = useState(false);
  if (!text) return null;
  const copy = async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <div className="codeblock">
      <div className="codeblock-head">
        <span>{title}</span>
        <button type="button" className="link" onClick={copy}>{copied ? "Copied" : "Copy"}</button>
      </div>
      <pre>{text}</pre>
    </div>
  );
}

function ResultRow({ r, type }) {
  const [open, setOpen] = useState(false);
  const where = r.line ? `Line ${r.line}` : r.httpStatus ? `HTTP ${r.httpStatus}` : "n/a";
  const expandable = r.status !== "Pass" || r.description;
  return (
    <>
      <tr className={`row ${open ? "open" : ""}`} onClick={() => expandable && setOpen(!open)}>
        <td>{r.owasp}</td>
        <td>
          <button type="button" className="rowbtn" aria-expanded={open}>{r.aspect}</button>
          <div className="muted small">{r.ruleId}</div>
        </td>
        <td><Pill kind={`s-${r.status}`}>{r.status}</Pill></td>
        <td>{r.severity === "None" ? "-" : <Pill kind={`v-${r.severity}`}>{r.severity}</Pill>}</td>
        <td className="mono">{where}</td>
        <td className="mono">{r.cwe || "-"}</td>
      </tr>
      {open && (
        <tr className="detail">
          <td colSpan={6}>
            <p>{r.description}</p>
            {r.evidence && <p className="muted"><strong>Evidence:</strong> {r.evidence}</p>}
            {r.code && <CodeBlock title={`Vulnerable code (line ${r.line})`} text={r.code} />}
            {r.recommendation && <p><strong>How to fix:</strong> {r.recommendation}</p>}
            {r.aiExplanation && <p className="ai"><strong>AI review:</strong> {r.aiExplanation}</p>}
            <CodeBlock title="AI-suggested fix" text={r.aiFixedCode} />
            <CodeBlock title="Secure code example" text={r.fixedCode} />
          </td>
        </tr>
      )}
    </>
  );
}

function Report({ report }) {
  const [status, setStatus] = useState("Issues");
  const [severity, setSeverity] = useState("All");
  const [owasp, setOwasp] = useState("All");

  useEffect(() => { setStatus("Issues"); setSeverity("All"); setOwasp("All"); }, [report.id]);

  const rows = useMemo(() => report.results.filter((r) =>
    (status === "All" || (status === "Issues" ? r.status === "Fail" || r.status === "Warning" : r.status === status)) &&
    (severity === "All" || r.severity === severity) &&
    (owasp === "All" || r.owasp === owasp)), [report, status, severity, owasp]);

  const download = () => {
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `securereview-${report.id || "report"}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <section className="report" aria-label="Review report">
      <header className="report-head">
        <div className={`grade g-${report.grade}`} aria-label={`Score ${report.score}, grade ${report.grade}`}>
          <span className="score">{report.score}</span>
          <span className="gl">Grade {report.grade}</span>
        </div>
        <div className="report-meta">
          <h2>{report.type === "Url" ? "API scan" : "Code review"}: {report.target}</h2>
          <p className="muted">{report.summary} {new Date(report.createdAt).toLocaleString()}{report.aiUsed ? " · AI fixes included" : ""}</p>
          <div className="counts">
            {SEVERITIES.map((s) => (
              <span key={s} className={`count v-${s}`}>{report.counts[s.toLowerCase()]} {s}</span>
            ))}
          </div>
        </div>
        <div className="report-actions no-print">
          <button type="button" className="btn ghost" onClick={download}>Download JSON</button>
          <button type="button" className="btn ghost" onClick={() => window.print()}>Print</button>
        </div>
      </header>

      <div className="owasp-grid" role="list">
        {report.categories.map((c) => (
          <button
            key={c.owasp} role="listitem" type="button"
            className={`tile t-${c.status} ${owasp === c.owasp ? "sel" : ""}`}
            onClick={() => setOwasp(owasp === c.owasp ? "All" : c.owasp)}
            title={`${c.owasp} ${c.name}`}
          >
            <strong>{c.owasp}</strong>
            <span className="tname">{c.name}</span>
            <span className="tstat">
              {c.status === "NotTested" ? "Not tested" : `${c.failed} fail · ${c.warnings} warn · ${c.passed} pass`}
            </span>
          </button>
        ))}
      </div>

      <div className="filters no-print">
        <label>Status
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option>Issues</option><option>All</option>
            {STATUSES.map((s) => <option key={s}>{s}</option>)}
          </select>
        </label>
        <label>Severity
          <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
            <option>All</option>{SEVERITIES.map((s) => <option key={s}>{s}</option>)}
          </select>
        </label>
        <span className="muted">{rows.length} of {report.results.length} tests shown{owasp !== "All" ? ` for ${owasp}` : ""}</span>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>OWASP</th><th>Test</th><th>Status</th><th>Severity</th><th>{report.type === "Url" ? "HTTP status" : "Code location"}</th><th>CWE</th></tr>
          </thead>
          <tbody>
            {rows.map((r) => <ResultRow key={r.id} r={r} type={report.type} />)}
            {rows.length === 0 && <tr><td colSpan={6} className="empty">Nothing matches these filters.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}

export default function App() {
  const [mode, setMode] = useState("code");
  const [code, setCode] = useState("");
  const [fileName, setFileName] = useState("");
  const [url, setUrl] = useState("");
  const [authorized, setAuthorized] = useState(false);
  const [useAi, setUseAi] = useState(false);
  const [aiAvailable, setAiAvailable] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [report, setReport] = useState(null);
  const [history, setHistory] = useState([]);

  const refresh = () => api.history().then(setHistory).catch(() => {});
  useEffect(() => {
    refresh();
    api.capabilities().then((c) => setAiAvailable(!!c.ai)).catch(() => {});
  }, []);

  const run = async () => {
    setError(""); setBusy(true);
    try {
      const r = mode === "code"
        ? await api.reviewCode({ code, fileName: fileName || null, useAi })
        : await api.reviewUrl({ url, authorized, useAi });
      setReport(r);
      refresh();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const open = async (id) => {
    setError("");
    try { setReport(await api.get(id)); } catch (e) { setError(e.message); }
  };

  const remove = async (id) => {
    await api.remove(id).catch(() => {});
    if (report?.id === id) setReport(null);
    refresh();
  };

  const canRun = !busy && (mode === "code" ? code.trim().length >= 10 : url.trim() && authorized);

  return (
    <div className="app">
      <header className="topbar no-print">
        <h1>SecureReview</h1>
        <p>Secure code review and vulnerability remediation for .NET, MongoDB and React apps</p>
      </header>

      <main className="layout">
        <aside className="side no-print">
          <div className="tabs" role="tablist">
            <button role="tab" aria-selected={mode === "code"} className={mode === "code" ? "on" : ""} onClick={() => setMode("code")}>Review code</button>
            <button role="tab" aria-selected={mode === "url"} className={mode === "url" ? "on" : ""} onClick={() => setMode("url")}>Scan API URL</button>
          </div>

          {mode === "code" ? (
            <div className="form">
              <label>File name (optional)
                <input value={fileName} onChange={(e) => setFileName(e.target.value)} placeholder="UsersController.cs" maxLength={260} />
              </label>
              <label>Code to review
                <textarea value={code} onChange={(e) => setCode(e.target.value)} rows={14} spellCheck={false}
                  placeholder="Paste C#, React/JS, a .csproj, package.json, appsettings.json or HTML." />
              </label>
              <button type="button" className="link" onClick={() => { setCode(sampleCode); setFileName("Program.cs (sample)"); }}>
                Load sample vulnerable code
              </button>
            </div>
          ) : (
            <div className="form">
              <label>API or site URL
                <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://api.example.com/api/health" maxLength={2048} />
              </label>
              <label className="check">
                <input type="checkbox" checked={authorized} onChange={(e) => setAuthorized(e.target.checked)} />
                <span>I own this system or have written permission to test it.</span>
              </label>
              <p className="muted small">
                The scan is passive: a handful of GET and OPTIONS requests that check HTTPS, headers, CORS, cookies,
                error pages, exposed files and input reflection. It never sends exploit payloads, follows redirects or
                reaches private network addresses (unless the server runs in Development).
              </p>
            </div>
          )}

          <label className={`check ${aiAvailable ? "" : "off"}`}>
            <input type="checkbox" checked={useAi && aiAvailable} disabled={!aiAvailable} onChange={(e) => setUseAi(e.target.checked)} />
            <span>Add AI-written explanations and fixes {aiAvailable ? "" : "(set ANTHROPIC_API_KEY on the API to enable)"}</span>
          </label>

          <button type="button" className="btn" disabled={!canRun} onClick={run}>
            {busy ? "Analysing…" : mode === "code" ? "Review code" : "Scan URL"}
          </button>
          {error && <p className="error" role="alert">{error}</p>}

          <h3>Recent reviews</h3>
          {history.length === 0 && <p className="muted small">Reports you run are saved here.</p>}
          <ul className="history">
            {history.map((h) => (
              <li key={h.id}>
                <button type="button" className="hist-open" onClick={() => open(h.id)}>
                  <span className={`mini g-${h.grade}`}>{h.score}</span>
                  <span className="hist-text">
                    <span className="hist-target">{h.target}</span>
                    <span className="muted small">{h.type === "Url" ? "API scan" : "Code"} · {new Date(h.createdAt).toLocaleString()}</span>
                  </span>
                </button>
                <button type="button" className="link danger" aria-label={`Delete report for ${h.target}`} onClick={() => remove(h.id)}>Delete</button>
              </li>
            ))}
          </ul>
        </aside>

        <div className="content">
          {report ? <Report report={report} /> : (
            <div className="placeholder">
              <h2>Run a review to see OWASP Top 10 results</h2>
              <p>Paste code or enter an API URL on the left. Each report lists every test with its status, severity,
                code location or HTTP status, CWE, and a secure code example for each issue.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
