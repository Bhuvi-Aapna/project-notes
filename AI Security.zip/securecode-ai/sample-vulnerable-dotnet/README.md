This intentionally vulnerable project is for local security scanner testing only.
Do not deploy it to a public environment.
