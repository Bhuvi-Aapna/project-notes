using System.Diagnostics;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddCors(o => o.AddPolicy("all", p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));
builder.Services.AddAuthentication().AddJwtBearer(o =>
{
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = false,
        ValidateAudience = false,
        ValidateLifetime = false,
        IssuerSigningKey = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes("super-secret-key-123"))
    };
});
var app = builder.Build();
app.UseDeveloperExceptionPage();
app.UseSwagger();
app.MapControllers();
app.Run();

[ApiController]
[Route("api/users")]
public class UsersController : ControllerBase
{
    private readonly ILogger<UsersController> _logger;
    private const string dbPassword = "P@ssw0rd123";
    private readonly HttpClient _http = new();

    public UsersController(ILogger<UsersController> logger) { _logger = logger; }

    [HttpGet("search")]
    public async Task<IActionResult> Search(string name)
    {
        var sql = "SELECT * FROM Users WHERE Name = '" + name + "'";
        using var cmd = new SqlCommand($"SELECT * FROM Users WHERE Email = '{name}'");
        var filter = MongoDB.Bson.BsonDocument.Parse(name);
        return Ok();
    }

    [HttpPost("login")]
    public IActionResult Login(LoginModel model)
    {
        var user = Find(model.Email);
        if (user.Password == model.Password)
        {
            _logger.LogInformation("Login ok for {u} with password {model.Password}");
            var token = new Random().Next().ToString();
            return Ok(token);
        }
        return Unauthorized();
    }

    [HttpGet("export")]
    public IActionResult Export(string fileName, string returnUrl, string url)
    {
        var text = System.IO.File.ReadAllText("/data/" + fileName);
        Process.Start("convert", fileName);
        var data = _http.GetStringAsync(url).Result;
        using var md5 = MD5.Create();
        var callback = "http://partner.example.com/callback";
        var settings = new Newtonsoft.Json.JsonSerializerSettings { TypeNameHandling = Newtonsoft.Json.TypeNameHandling.All };
        try { Validate(); } catch (Exception) { }
        try { return Redirect(returnUrl); }
        catch (Exception ex) { return BadRequest(ex.Message); }
    }

    [HttpGet("profile")]
    public IActionResult Profile(string bio) => Content(Html.Raw(bio), "text/html");
}
