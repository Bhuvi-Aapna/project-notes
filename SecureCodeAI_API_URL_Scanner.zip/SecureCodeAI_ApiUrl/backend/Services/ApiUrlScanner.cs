using System.Net;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text.Json;
using SecureCodeAI.Api.Models;

namespace SecureCodeAI.Api.Services;

public sealed class ApiUrlScanner
{
    private readonly HttpClient _http;
    private readonly IConfiguration _configuration;

    private static readonly string[] CommonSwaggerPaths =
    [
        "/swagger/v1/swagger.json",
        "/swagger/swagger.json",
        "/swagger.json",
        "/openapi.json",
        "/openapi/v1.json",
        "/api/swagger.json",
        "/api/openapi.json"
    ];

    public ApiUrlScanner(
        IHttpClientFactory factory,
        IConfiguration configuration)
    {
        _http = factory.CreateClient("scanner");
        _configuration = configuration;
    }

    public async Task<ScanResult> ScanAsync(
        string targetUrl,
        string? bearerToken,
        CancellationToken ct)
    {
        targetUrl = NormalizeUrl(targetUrl);

        await ValidateTargetAsync(targetUrl, ct);

        var findings = new List<Finding>();

        var swagger = await DiscoverSwaggerAsync(
            targetUrl,
            bearerToken,
            ct);

        if (swagger is null)
        {
            findings.Add(new Finding
            {
                Source = "Discovery",
                Rule = "DISC001",
                Title = "Swagger/OpenAPI Document Not Found",
                Severity = Severity.Medium,
                Cwe = "CWE-200",
                Owasp = "A05:2021 Security Misconfiguration",
                Description = "No common Swagger/OpenAPI JSON document could be discovered from the supplied application URL.",
                Evidence = targetUrl,
                Recommendation = "Provide the direct Swagger/OpenAPI JSON URL or expose a documented OpenAPI endpoint."
            });
        }
        else
        {
            ScanOpenApi(
                swagger.Value.Document,
                swagger.Value.Url,
                findings);
        }

        var liveChecks = await RunPassiveHttpChecksAsync(
            targetUrl,
            bearerToken,
            ct);

        AddLiveFindings(
            targetUrl,
            liveChecks,
            findings);

        var counts = Enum.GetValues<Severity>()
            .ToDictionary(
                s => s.ToString(),
                s => findings.Count(x => x.Severity == s));

        var endpoints = swagger is null
            ? 0
            : CountEndpoints(swagger.Value.Document);

        return new ScanResult
        {
            TargetUrl = targetUrl,
            SwaggerUrl = swagger?.Url ?? "",
            CreatedAtUtc = DateTime.UtcNow,
            SecurityScore = CalculateScore(findings),
            EndpointsAnalyzed = endpoints,
            Findings = findings,
            SeverityCounts = counts,
            LiveChecks = liveChecks
        };
    }

    private async Task<(string Url, JsonDocument Document)?> DiscoverSwaggerAsync(
        string targetUrl,
        string? token,
        CancellationToken ct)
    {
        var candidates = new List<string> { targetUrl };

        if (targetUrl.EndsWith(
                ".json",
                StringComparison.OrdinalIgnoreCase))
        {
            candidates = [targetUrl];
        }
        else
        {
            var baseUri = new Uri(targetUrl);

            candidates.AddRange(
                CommonSwaggerPaths.Select(path =>
                    new Uri(baseUri, path).ToString()));

            if (targetUrl.EndsWith(
                    "/swagger/index.html",
                    StringComparison.OrdinalIgnoreCase))
            {
                candidates.Insert(
                    0,
                    new Uri(
                        new Uri(targetUrl),
                        "/swagger/v1/swagger.json").ToString());
            }
        }

        foreach (var candidate in candidates.Distinct())
        {
            try
            {
                using var request = new HttpRequestMessage(
                    HttpMethod.Get,
                    candidate);

                AddBearer(request, token);

                using var response = await _http.SendAsync(
                    request,
                    HttpCompletionOption.ResponseHeadersRead,
                    ct);

                if (!response.IsSuccessStatusCode)
                    continue;

                var contentType =
                    response.Content.Headers.ContentType?.MediaType ?? "";

                var body = await response.Content.ReadAsStringAsync(ct);

                if (!contentType.Contains("json", StringComparison.OrdinalIgnoreCase) &&
                    !LooksLikeOpenApi(body))
                    continue;

                var document = JsonDocument.Parse(body);

                if (document.RootElement.TryGetProperty(
                        "openapi",
                        out _) ||
                    document.RootElement.TryGetProperty(
                        "swagger",
                        out _))
                {
                    return (candidate, document);
                }

                document.Dispose();
            }
            catch
            {
                // Try the next candidate.
            }
        }

        return null;
    }

    private static bool LooksLikeOpenApi(string text) =>
        text.Contains("\"openapi\"", StringComparison.OrdinalIgnoreCase) ||
        text.Contains("\"swagger\"", StringComparison.OrdinalIgnoreCase);

    private static void ScanOpenApi(
        JsonDocument document,
        string swaggerUrl,
        List<Finding> findings)
    {
        var root = document.RootElement;

        ScanServers(root, swaggerUrl, findings);

        if (!root.TryGetProperty(
                "paths",
                out var paths))
            return;

        var hasGlobalSecurity =
            root.TryGetProperty(
                "security",
                out var globalSecurity) &&
            globalSecurity.ValueKind == JsonValueKind.Array &&
            globalSecurity.GetArrayLength() > 0;

        var hasSecurityScheme = HasSecurityScheme(root);

        if (!hasSecurityScheme)
        {
            findings.Add(new Finding
            {
                Source = "Swagger",
                Rule = "API005",
                Title = "No Security Scheme Documented",
                Severity = Severity.High,
                Cwe = "CWE-16",
                Owasp = "A05:2021 Security Misconfiguration",
                Description = "The OpenAPI document does not define a security scheme.",
                Evidence = swaggerUrl,
                Recommendation = "Define the application's authentication mechanism in OpenAPI and enforce it server-side."
            });
        }

        foreach (var path in paths.EnumerateObject())
        {
            foreach (var operation in path.Value.EnumerateObject())
            {
                if (!IsHttpMethod(operation.Name))
                    continue;

                var method = operation.Name.ToUpperInvariant();
                var endpoint = path.Name;

                var hasOperationSecurity =
                    operation.Value.TryGetProperty(
                        "security",
                        out var security) &&
                    security.ValueKind == JsonValueKind.Array;

                var protectedByGlobal =
                    hasGlobalSecurity &&
                    security is { ValueKind: JsonValueKind.Undefined };

                if (!hasOperationSecurity &&
                    !protectedByGlobal)
                {
                    findings.Add(new Finding
                    {
                        Source = "Swagger",
                        Rule = "API002",
                        Title = "API Operation Has No Security Requirement",
                        Severity = IsSensitive(endpoint)
                            ? Severity.High
                            : Severity.Medium,
                        Cwe = "CWE-306",
                        Owasp = "A07:2021 Identification and Authentication Failures",
                        Endpoint = endpoint,
                        Method = method,
                        Description = "The OpenAPI operation does not declare a security requirement and is not clearly protected by a global security definition.",
                        Evidence = $"{method} {endpoint}",
                        Recommendation = "Review whether the endpoint should require authentication and document the appropriate security requirement."
                    });
                }

                if (ContainsObjectIdentifier(endpoint))
                {
                    findings.Add(new Finding
                    {
                        Source = "Swagger",
                        Rule = "API003",
                        Title = "Object-Level Authorization Review Required",
                        Severity = Severity.High,
                        Cwe = "CWE-639",
                        Owasp = "A01:2021 Broken Access Control",
                        Endpoint = endpoint,
                        Method = method,
                        Description = "The endpoint contains an object identifier. Swagger cannot prove that the authenticated caller owns or may access that object.",
                        Evidence = $"{method} {endpoint}",
                        Recommendation = "Verify tenant/owner authorization on the server for every object identifier."
                    });
                }

                if (method == "GET" && IsSensitive(endpoint))
                {
                    findings.Add(new Finding
                    {
                        Source = "Swagger",
                        Rule = "API004",
                        Title = "Sensitive GET Endpoint",
                        Severity = Severity.Medium,
                        Cwe = "CWE-200",
                        Owasp = "A01:2021 Broken Access Control",
                        Endpoint = endpoint,
                        Method = method,
                        Description = "The endpoint name suggests sensitive data may be returned through GET.",
                        Evidence = $"{method} {endpoint}",
                        Recommendation = "Review authorization, response data, caching, and whether sensitive input is exposed in query strings."
                    });
                }

                if (!operation.Value.TryGetProperty(
                        "responses",
                        out var responses) ||
                    responses.ValueKind != JsonValueKind.Object ||
                    responses.EnumerateObject().Count() == 0)
                {
                    findings.Add(new Finding
                    {
                        Source = "Swagger",
                        Rule = "API006",
                        Title = "Operation Has No Documented Responses",
                        Severity = Severity.Low,
                        Cwe = "CWE-16",
                        Owasp = "A05:2021 Security Misconfiguration",
                        Endpoint = endpoint,
                        Method = method,
                        Description = "The API operation has no documented response definitions.",
                        Evidence = $"{method} {endpoint}",
                        Recommendation = "Document successful and expected error responses."
                    });
                }
            }
        }
    }

    private static void ScanServers(
        JsonElement root,
        string swaggerUrl,
        List<Finding> findings)
    {
        if (!root.TryGetProperty("servers", out var servers))
            return;

        foreach (var server in servers.EnumerateArray())
        {
            if (!server.TryGetProperty("url", out var urlElement))
                continue;

            var url = urlElement.GetString() ?? "";

            if (url.StartsWith(
                    "http://",
                    StringComparison.OrdinalIgnoreCase))
            {
                findings.Add(new Finding
                {
                    Source = "Swagger",
                    Rule = "API001",
                    Title = "Swagger Server Uses HTTP",
                    Severity = Severity.High,
                    Cwe = "CWE-319",
                    Owasp = "A02:2021 Cryptographic Failures",
                    Endpoint = url,
                    Description = "The OpenAPI server URL uses HTTP instead of HTTPS.",
                    Evidence = url,
                    Recommendation = "Use HTTPS for production API endpoints."
                });
            }
        }
    }

    private static async Task<Dictionary<string, string>>
        RunPassiveHttpChecksAsync(
            string targetUrl,
            string? token,
            CancellationToken ct)
    {
        var result = new Dictionary<string, string>();

        try
        {
            using var request = new HttpRequestMessage(
                HttpMethod.Get,
                targetUrl);

            AddBearer(request, token);

            using var response = await new HttpClient().SendAsync(
                request,
                HttpCompletionOption.ResponseHeadersRead,
                ct);

            result["HTTP Status"] = ((int)response.StatusCode).ToString();
            result["HTTPS"] = new Uri(targetUrl).Scheme == "https"
                ? "Yes"
                : "No";

            result["Strict-Transport-Security"] =
                response.Headers.TryGetValues(
                    "Strict-Transport-Security",
                    out var hsts)
                    ? hsts.FirstOrDefault() ?? "Present"
                    : "Missing";

            result["Content-Security-Policy"] =
                response.Headers.TryGetValues(
                    "Content-Security-Policy",
                    out var csp)
                    ? csp.FirstOrDefault() ?? "Present"
                    : "Missing";

            result["X-Content-Type-Options"] =
                response.Headers.TryGetValues(
                    "X-Content-Type-Options",
                    out var xcto)
                    ? xcto.FirstOrDefault() ?? "Present"
                    : "Missing";

            result["Access-Control-Allow-Origin"] =
                response.Headers.TryGetValues(
                    "Access-Control-Allow-Origin",
                    out var cors)
                    ? cors.FirstOrDefault() ?? "Present"
                    : "Not observed";

            result["Server"] =
                response.Headers.Server?.ToString() ?? "Not exposed";
        }
        catch (Exception ex)
        {
            result["HTTP Check"] = $"Failed: {ex.Message}";
        }

        return result;
    }

    private static void AddLiveFindings(
        string targetUrl,
        Dictionary<string, string> checks,
        List<Finding> findings)
    {
        if (checks.TryGetValue("HTTPS", out var https) &&
            https == "No")
        {
            findings.Add(new Finding
            {
                Source = "HTTP",
                Rule = "HTTP001",
                Title = "Target API Uses HTTP",
                Severity = Severity.High,
                Cwe = "CWE-319",
                Owasp = "A02:2021 Cryptographic Failures",
                Description = "The target API URL uses unencrypted HTTP.",
                Evidence = targetUrl,
                Recommendation = "Use HTTPS/TLS for the API."
            });
        }

        if (checks.TryGetValue(
                "Access-Control-Allow-Origin",
                out var cors) &&
            cors == "*")
        {
            findings.Add(new Finding
            {
                Source = "HTTP",
                Rule = "HTTP002",
                Title = "Wildcard CORS Observed",
                Severity = Severity.Medium,
                Cwe = "CWE-942",
                Owasp = "A05:2021 Security Misconfiguration",
                Description = "The target API response exposes Access-Control-Allow-Origin: *.",
                Evidence = cors,
                Recommendation = "Restrict CORS to trusted application origins where credentials or sensitive data are involved."
            });
        }

        if (checks.TryGetValue(
                "Strict-Transport-Security",
                out var hsts) &&
            hsts == "Missing")
        {
            findings.Add(new Finding
            {
                Source = "HTTP",
                Rule = "HTTP003",
                Title = "HSTS Header Not Observed",
                Severity = Severity.Low,
                Cwe = "CWE-319",
                Owasp = "A05:2021 Security Misconfiguration",
                Description = "Strict-Transport-Security was not observed on the target response.",
                Evidence = "Strict-Transport-Security: Missing",
                Recommendation = "Consider enabling HSTS on HTTPS production APIs."
            });
        }

        if (checks.TryGetValue(
                "X-Content-Type-Options",
                out var xcto) &&
            xcto == "Missing")
        {
            findings.Add(new Finding
            {
                Source = "HTTP",
                Rule = "HTTP004",
                Title = "X-Content-Type-Options Not Observed",
                Severity = Severity.Low,
                Cwe = "CWE-693",
                Owasp = "A05:2021 Security Misconfiguration",
                Description = "The target response did not expose X-Content-Type-Options.",
                Evidence = "X-Content-Type-Options: Missing",
                Recommendation = "Consider sending X-Content-Type-Options: nosniff."
            });
        }
    }

    private static bool HasSecurityScheme(JsonElement root)
    {
        if (!root.TryGetProperty(
                "components",
                out var components))
            return false;

        if (!components.TryGetProperty(
                "securitySchemes",
                out var schemes))
            return false;

        return schemes.ValueKind == JsonValueKind.Object &&
               schemes.EnumerateObject().Any();
    }

    private static bool ContainsObjectIdentifier(string endpoint) =>
        endpoint.Contains("{id}", StringComparison.OrdinalIgnoreCase) ||
        endpoint.Contains("{userId}", StringComparison.OrdinalIgnoreCase) ||
        endpoint.Contains("{accountId}", StringComparison.OrdinalIgnoreCase) ||
        endpoint.Contains("{customerId}", StringComparison.OrdinalIgnoreCase) ||
        endpoint.Contains("{orderId}", StringComparison.OrdinalIgnoreCase);

    private static bool IsSensitive(string endpoint)
    {
        var value = endpoint.ToLowerInvariant();

        return value.Contains("admin") ||
               value.Contains("password") ||
               value.Contains("token") ||
               value.Contains("secret") ||
               value.Contains("user") ||
               value.Contains("account") ||
               value.Contains("payment") ||
               value.Contains("transaction");
    }

    private static bool IsHttpMethod(string method) =>
        method is "get" or "post" or "put" or "patch" or "delete" or "options" or "head";

    private static int CountEndpoints(JsonDocument document)
    {
        if (!document.RootElement.TryGetProperty(
                "paths",
                out var paths))
            return 0;

        return paths.EnumerateObject()
            .Sum(path => path.Value.EnumerateObject()
                .Count(op => IsHttpMethod(op.Name)));
    }

    public static int CalculateScore(List<Finding> findings)
    {
        var deductions = findings.Sum(f => f.Severity switch
        {
            Severity.Critical => 20,
            Severity.High => 10,
            Severity.Medium => 5,
            Severity.Low => 2,
            _ => 0
        });

        return Math.Max(0, 100 - deductions);
    }

    private static string NormalizeUrl(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("API URL is required.");

        if (!Uri.TryCreate(value.Trim(), UriKind.Absolute, out var uri))
            throw new ArgumentException("Enter a valid absolute HTTP/HTTPS URL.");

        if (uri.Scheme != Uri.UriSchemeHttp &&
            uri.Scheme != Uri.UriSchemeHttps)
            throw new ArgumentException("Only HTTP and HTTPS URLs are supported.");

        return uri.ToString().TrimEnd('/');
    }

    private async Task ValidateTargetAsync(
        string url,
        CancellationToken ct)
    {
        var allowPrivate =
            _configuration.GetValue(
                "Scanner:AllowPrivateNetworks",
                true);

        if (allowPrivate)
            return;

        var uri = new Uri(url);

        var addresses = await Dns.GetHostAddressesAsync(
            uri.DnsSafeHost,
            ct);

        foreach (var address in addresses)
        {
            if (IsPrivateOrLoopback(address))
            {
                throw new InvalidOperationException(
                    "Target resolves to a private/loopback network. " +
                    "Production scanners should require an explicit allow-list.");
            }
        }
    }

    private static bool IsPrivateOrLoopback(IPAddress address)
    {
        if (IPAddress.IsLoopback(address))
            return true;

        if (address.AddressFamily == AddressFamily.InterNetwork)
        {
            var bytes = address.GetAddressBytes();

            return bytes[0] == 10 ||
                   (bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31) ||
                   (bytes[0] == 192 && bytes[1] == 168) ||
                   (bytes[0] == 169 && bytes[1] == 254);
        }

        return address.IsIPv6LinkLocal ||
               address.IsIPv6SiteLocal;
    }

    private static void AddBearer(
        HttpRequestMessage request,
        string? token)
    {
        if (!string.IsNullOrWhiteSpace(token))
            request.Headers.Authorization =
                new AuthenticationHeaderValue(
                    "Bearer",
                    token.Trim());
    }
}
