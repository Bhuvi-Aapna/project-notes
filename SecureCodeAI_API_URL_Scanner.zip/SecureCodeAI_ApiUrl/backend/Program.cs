using System.Net.Http;
using SecureCodeAI.Api.Options;
using SecureCodeAI.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<MongoDbOptions>(
    builder.Configuration.GetSection("MongoDb"));

builder.Services.AddSingleton<MongoDbService>();

builder.Services.AddHttpClient(
    "scanner",
    client =>
    {
        client.Timeout = TimeSpan.FromSeconds(
            builder.Configuration.GetValue(
                "Scanner:RequestTimeoutSeconds",
                15));

        client.DefaultRequestHeaders.UserAgent.ParseAdd(
            "SecureCodeAI-Authorized-Scanner/1.0");
    })
    .ConfigurePrimaryHttpMessageHandler(() =>
        new HttpClientHandler
        {
            AllowAutoRedirect = false
        });

builder.Services.AddSingleton<ApiUrlScanner>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddCors(options =>
{
    options.AddPolicy("frontend", policy =>
    {
        policy
            .SetIsOriginAllowed(origin =>
                origin.StartsWith(
                    "http://localhost:",
                    StringComparison.OrdinalIgnoreCase) ||
                origin.StartsWith(
                    "https://localhost:",
                    StringComparison.OrdinalIgnoreCase))
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseCors("frontend");

app.MapGet("/health", () =>
    Results.Ok(new
    {
        status = "ok",
        service = "SecureCodeAI.Api",
        utc = DateTime.UtcNow
    }));

app.MapControllers();

app.Run("http://localhost:5080");
