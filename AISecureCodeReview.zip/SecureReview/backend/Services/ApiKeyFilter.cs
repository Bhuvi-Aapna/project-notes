using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace SecureReview.Api.Services;

/// <summary>Optional shared-secret guard. Active only when Security:ApiKey is set. Replace with Azure AD / JWT in production.</summary>
public class ApiKeyFilter(IConfiguration cfg) : IAsyncActionFilter
{
    public async Task OnActionExecutionAsync(ActionExecutingContext ctx, ActionExecutionDelegate next)
    {
        var expected = cfg["Security:ApiKey"];
        if (!string.IsNullOrEmpty(expected))
        {
            var got = ctx.HttpContext.Request.Headers["X-Api-Key"].ToString();
            var ok = CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(got), Encoding.UTF8.GetBytes(expected));
            if (!ok)
            {
                ctx.Result = new UnauthorizedObjectResult(new { error = "Missing or invalid API key." });
                return;
            }
        }
        await next();
    }
}
