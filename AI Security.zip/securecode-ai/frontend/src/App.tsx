import { useState } from "react";

type Severity = "Low" | "Medium" | "High" | "Critical";

type Finding = {
  id: string;
  file: string;
  line: number;
  rule: string;
  title: string;
  severity: Severity;
  cwe: string;
  owasp: string;
  description: string;
  evidence: string;
  recommendation: string;
  autoFixAvailable: boolean;
};

type ScanResult = {
  scanId: string;
  projectName: string;
  createdAtUtc: string;
  filesScanned: number;
  findings: Finding[];
  securityScore: number;
};

type Remediation = {
  explanation: string;
  before: string;
  after: string;
  validation: string;
  appliedAutomatically: boolean;
};

function App() {
  const [file, setFile] = useState<File | null>(null);
  const [scan, setScan] = useState<ScanResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [remediating, setRemediating] = useState<string | null>(null);
  const [remediation, setRemediation] = useState<Remediation | null>(null);
  const [error, setError] = useState("");

  async function scanProject() {
    if (!file) return;

    setLoading(true);
    setError("");
    setRemediation(null);

    try {
      const form = new FormData();
      form.append("file", file);

      const response = await fetch("/api/scans/upload", {
        method: "POST",
        body: form
      });

      if (!response.ok) {
        throw new Error(await response.text());
      }

      setScan(await response.json());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Scan failed");
    } finally {
      setLoading(false);
    }
  }

  async function remediate(finding: Finding) {
    if (!scan) return;

    setRemediating(finding.id);
    setError("");

    try {
      const response = await fetch(
        `/api/scans/${scan.scanId}/remediate/${finding.id}`,
        { method: "POST" }
      );

      if (!response.ok) {
        throw new Error(await response.text());
      }

      setRemediation(await response.json());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Remediation failed");
    } finally {
      setRemediating(null);
    }
  }

  const critical = scan?.findings.filter(x => x.severity === "Critical").length ?? 0;
  const high = scan?.findings.filter(x => x.severity === "High").length ?? 0;
  const medium = scan?.findings.filter(x => x.severity === "Medium").length ?? 0;

  return (
    <div className="app">
      <header>
        <div>
          <div className="brand">SECURECODE <span>AI</span></div>
          <div className="subtitle">AI-Powered .NET Security Review & Remediation</div>
        </div>
        <div className="badge">AI ARENA 2026</div>
      </header>

      <main>
        <section className="hero">
          <div>
            <h1>Secure your .NET code before attackers do.</h1>
            <p>
              Upload a .NET project, detect security vulnerabilities, understand
              the risk and generate remediation guidance.
            </p>
          </div>

          <div className="upload-card">
            <input
              type="file"
              accept=".zip"
              onChange={e => setFile(e.target.files?.[0] ?? null)}
            />
            <button disabled={!file || loading} onClick={scanProject}>
              {loading ? "Scanning..." : "Start Security Scan"}
            </button>
            <small>{file ? file.name : "Upload a .NET project ZIP"}</small>
          </div>
        </section>

        {error && <div className="error">{error}</div>}

        {scan && (
          <>
            <section className="stats">
              <div className="score">
                <small>Security Score</small>
                <strong>{scan.securityScore}</strong>
                <span>/100</span>
              </div>
              <Stat label="Critical" value={critical} cls="critical" />
              <Stat label="High" value={high} cls="high" />
              <Stat label="Medium" value={medium} cls="medium" />
              <Stat label="Files Scanned" value={scan.filesScanned} cls="neutral" />
            </section>

            <section className="panel">
              <div className="panel-title">
                <div>
                  <h2>{scan.projectName}</h2>
                  <p>{scan.findings.length} security findings detected</p>
                </div>
                <span className="scan-id">Scan: {scan.scanId.slice(0, 10)}</span>
              </div>

              {scan.findings.length === 0 ? (
                <div className="success">No findings detected by the current rules.</div>
              ) : (
                <div className="findings">
                  {scan.findings.map(f => (
                    <article className="finding" key={f.id}>
                      <div className={`severity ${f.severity.toLowerCase()}`}>
                        {f.severity}
                      </div>

                      <div className="finding-body">
                        <h3>{f.title}</h3>
                        <div className="meta">
                          {f.file}:{f.line} · {f.cwe} · {f.owasp}
                        </div>
                        <p>{f.description}</p>
                        <pre>{f.evidence}</pre>
                        <p><b>Recommendation:</b> {f.recommendation}</p>
                        <button
                          className="fix"
                          disabled={remediating === f.id}
                          onClick={() => remediate(f)}
                        >
                          {remediating === f.id ? "Generating..." : "Generate AI Fix"}
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </section>

            {remediation && (
              <section className="panel remediation">
                <h2>AI Remediation</h2>
                <p><b>Why:</b> {remediation.explanation}</p>

                <div className="code-grid">
                  <div>
                    <h3>Before</h3>
                    <pre>{remediation.before}</pre>
                  </div>
                  <div>
                    <h3>After</h3>
                    <pre>{remediation.after}</pre>
                  </div>
                </div>

                <div className="validation">
                  <b>Validation:</b> {remediation.validation}
                </div>
              </section>
            )}
          </>
        )}
      </main>
    </div>
  );
}

function Stat({
  label,
  value,
  cls
}: {
  label: string;
  value: number;
  cls: string;
}) {
  return (
    <div className={`stat ${cls}`}>
      <small>{label}</small>
      <strong>{value}</strong>
    </div>
  );
}

export default App;
