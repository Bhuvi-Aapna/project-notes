namespace SecureCodeAI.Api.Models;

public enum Severity
{
    Low,
    Medium,
    High,
    Critical
}

public sealed record Finding(
    string Id,
    string File,
    int Line,
    string Rule,
    string Title,
    Severity Severity,
    string Cwe,
    string Owasp,
    string Description,
    string Evidence,
    string Recommendation,
    bool AutoFixAvailable
);

public sealed record ScanResult(
    string ScanId,
    string ProjectName,
    DateTime CreatedAtUtc,
    int FilesScanned,
    List<Finding> Findings,
    int SecurityScore
);

public sealed record RemediationResult(
    string FindingId,
    string File,
    int Line,
    string Explanation,
    string Before,
    string After,
    bool AppliedAutomatically,
    string Validation
);
