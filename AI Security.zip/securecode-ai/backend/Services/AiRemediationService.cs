using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using SecureCodeAI.Api.Models;

namespace SecureCodeAI.Api.Services;

public sealed class AiRemediationService
{
    private readonly HttpClient _http = new();

    public async Task<RemediationResult> GenerateAsync(
        Finding finding,
        string source,
        CancellationToken cancellationToken)
    {
        var baseUrl = Environment.GetEnvironmentVariable("AI_BASE_URL");
        var apiKey = Environment.GetEnvironmentVariable("AI_API_KEY");
        var model = Environment.GetEnvironmentVariable("AI_MODEL") ?? "gpt-4o-mini";

        if (!string.IsNullOrWhiteSpace(baseUrl) && !string.IsNullOrWhiteSpace(apiKey))
        {
            return await GenerateWithLlmAsync(
                baseUrl!, apiKey!, model, finding, source, cancellationToken);
        }

        return GenerateDeterministic(finding, source);
    }

    private async Task<RemediationResult> GenerateWithLlmAsync(
        string baseUrl,
        string apiKey,
        string model,
        Finding finding,
        string source,
        CancellationToken cancellationToken)
    {
        var prompt = $"""
You are a senior .NET application security engineer.

Analyze this finding:
Rule: {finding.Rule}
Severity: {finding.Severity}
CWE: {finding.Cwe}
OWASP: {finding.Owasp}
Description: {finding.Description}
Evidence: {finding.Evidence}

Return JSON only:
{{
  "explanation": "...",
  "fixedCode": "...",
  "validation": "..."
}}

Return the COMPLETE corrected source file, not only a changed line.
Preserve business behavior where possible.
Do not invent classes, dependencies, or APIs that are not required.

Source file:
```csharp
{source}
```
""";

        var payload = JsonSerializer.Serialize(new
        {
            model,
            messages = new[]
            {
                new { role = "system", content = "You are a secure coding assistant for .NET." },
                new { role = "user", content = prompt }
            },
            temperature = 0.1
        });

        using var request = new HttpRequestMessage(
            HttpMethod.Post,
            $"{baseUrl.TrimEnd('/')}/chat/completions");

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
        request.Content = new StringContent(payload, Encoding.UTF8, "application/json");

        using var response = await _http.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"AI provider returned {(int)response.StatusCode}: {body}");

        using var json = JsonDocument.Parse(body);
        var content = json.RootElement
            .GetProperty("choices")[0]
            .GetProperty("message")
            .GetProperty("content")
            .GetString() ?? "{}";

        content = content.Replace("```json", "").Replace("```csharp", "").Replace("```", "").Trim();

        using var result = JsonDocument.Parse(content);
        var root = result.RootElement;

        return new RemediationResult(
            finding.Id,
            finding.File,
            finding.Line,
            root.GetProperty("explanation").GetString() ?? finding.Recommendation,
            source,
            root.GetProperty("fixedCode").GetString() ?? source,
            false,
            root.GetProperty("validation").GetString() ?? "Re-scan the corrected source before merging.");
    }

    private static RemediationResult GenerateDeterministic(Finding finding, string source)
    {
        var after = source;
        var explanation = finding.Recommendation;
        var applied = false;

        if (finding.Rule == "SQL_INJECTION")
        {
            // Handles the common MVP pattern:
            // var query = $"SELECT ... {value}";
            // ... FromSqlRaw(query)
            var match = Regex.Match(
                source,
                @"(?<indent>\s*)var\s+query\s*=\s*\$(?<quote>[""'])(?<sql>.*?)(?<!\\)\k<quote>\s*;\s*(?<rest>.*?)FromSqlRaw\s*\(\s*query\s*\)",
                RegexOptions.Singleline);

            if (match.Success)
            {
                var sql = match.Groups["sql"].Value;
                var rest = match.Groups["rest"].Value;
                var replacement = $"{match.Groups["indent"]}{rest}FromSqlInterpolated($\"{sql}\")";
                after = source.Remove(match.Index, match.Length).Insert(match.Index, replacement);
                explanation = "Replaced the raw SQL variable/FromSqlRaw pattern with FromSqlInterpolated so EF Core can parameterize interpolated values.";
                applied = true;
            }
            else
            {
                explanation = "Use a parameterized EF Core query. The deterministic fixer did not alter the source because the exact SQL pattern was not safely recognized.";
            }
        }
        else if (finding.Rule == "HARDCODED_SECRET")
        {
            explanation = "Move the credential to configuration or a managed secret store. The deterministic MVP intentionally does not rewrite secret names or configuration because the correct destination depends on the application's deployment model.";
        }
        else if (finding.Rule == "MISSING_AUTHORIZATION")
        {
            if (!source.Contains("[Authorize", StringComparison.OrdinalIgnoreCase))
            {
                after = "using Microsoft.AspNetCore.Authorization;\n" + source;
                explanation = "Added the authorization namespace. Review the endpoint and apply [Authorize] or an explicit policy at the controller/action level.";
                applied = true;
            }
        }

        return new RemediationResult(
            finding.Id,
            finding.File,
            finding.Line,
            explanation,
            source,
            after,
            applied,
            applied
                ? "The API should re-scan the corrected source. For production, add a sandboxed build/test/scan stage before applying changes automatically."
                : "No source was automatically changed. Apply the recommendation and re-scan.");
    }
}
