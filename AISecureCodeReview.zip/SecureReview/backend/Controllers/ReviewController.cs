using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecureReview.Api.Models;
using SecureReview.Api.Services;

namespace SecureReview.Api.Controllers;

[ApiController]
[Route("api/review")]
[EnableRateLimiting("scan")]
[ServiceFilter(typeof(ApiKeyFilter))]
public class ReviewController(
    CodeReviewEngine engine,
    UrlScanner scanner,
    AiRemediationService ai,
    ReviewRepository repo,
    ILogger<ReviewController> log) : ControllerBase
{
    /// <summary>Review pasted source code (C#, React/JS, csproj, package.json, appsettings, HTML).</summary>
    [HttpPost("code")]
    public async Task<ActionResult<ReviewReport>> ReviewCode([FromBody] CodeReviewRequest req, CancellationToken ct)
    {
        var results = engine.Review(req.Code);
        var aiUsed = false;
        if (req.UseAi && ai.Enabled) aiUsed = await ai.EnrichAsync(req.Code, results, ct) > 0;

        var report = ReportBuilder.Build("Code", string.IsNullOrWhiteSpace(req.FileName) ? "Pasted code" : req.FileName!.Trim(), results, aiUsed);
        await repo.InsertAsync(report, ct);
        log.LogInformation("Code review {Id} score {Score}", report.Id, report.Score);
        return Ok(report);
    }

    /// <summary>Passive OWASP checks of a live URL. The caller must confirm authorisation.</summary>
    [HttpPost("url")]
    public async Task<ActionResult<ReviewReport>> ReviewUrl([FromBody] UrlReviewRequest req, CancellationToken ct)
    {
        if (!req.Authorized)
            return BadRequest(new { error = "Confirm that you own or are authorised to test this URL." });
        if (!UrlScanner.TryParseTarget(req.Url, out var uri, out var error))
            return BadRequest(new { error });

        var results = await scanner.ScanAsync(uri, ct);
        var aiUsed = false;
        if (req.UseAi && ai.Enabled) aiUsed = await ai.EnrichAsync(null, results, ct) > 0;

        var report = ReportBuilder.Build("Url", uri.GetLeftPart(UriPartial.Path), results, aiUsed);
        await repo.InsertAsync(report, ct);
        return Ok(report);
    }

    [HttpGet]
    public async Task<ActionResult<List<ReportListItem>>> List([FromQuery] int limit = 30, CancellationToken ct = default) =>
        Ok(await repo.ListAsync(limit, ct));

    [HttpGet("{id}")]
    public async Task<ActionResult<ReviewReport>> Get(string id, CancellationToken ct)
    {
        var r = await repo.GetAsync(id, ct);
        return r is null ? NotFound() : Ok(r);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id, CancellationToken ct) =>
        await repo.DeleteAsync(id, ct) ? NoContent() : NotFound();

    /// <summary>Tells the UI whether AI remediation is configured.</summary>
    [HttpGet("capabilities")]
    public IActionResult Capabilities() => Ok(new { ai = ai.Enabled });
}
