# SecureCode AI - API URL / Swagger Security Scanner

This version does NOT require a project ZIP upload.

The user enters an authorized application API URL, for example:

https://api.example.com
https://api.example.com/swagger/index.html
https://api.example.com/swagger/v1/swagger.json
http://localhost:5080

The backend discovers the OpenAPI/Swagger document, analyzes the API contract and stores scan results in MongoDB.

## Important scope

An API URL alone does NOT provide the application's C# source code. Therefore this scanner can identify API-contract and configuration risks visible from the public API/Swagger surface, but it cannot prove source-code vulnerabilities such as SQL injection.

For source-code analysis, the application would additionally need:
- repository access, or
- a CI/CD integration, or
- a source-code analysis agent running inside the application environment.

## Checks included

### Swagger/OpenAPI
- HTTP server URL instead of HTTPS
- Missing operation security requirement
- Sensitive endpoint without security requirement
- ID/object identifier authorization review
- Sensitive GET endpoint
- Missing documented security scheme
- API operation with no responses
- API endpoint with wildcard-like server URL patterns

### Live API passive checks
- HTTPS usage
- Security headers
- CORS header observation
- Server header exposure
- OPTIONS response / allowed methods
- Authentication challenge visibility

The live checks are intentionally passive. The MVP does not attempt exploitation.

## Backend

```powershell
cd backend
dotnet restore
dotnet build
dotnet run
```

Backend:

http://localhost:5080

Swagger:

http://localhost:5080/swagger

## MongoDB

Default:

mongodb://localhost:27017

Database:

SecureCodeAI

Collection:

scans

You can override:

```powershell
$env:MongoDb__ConnectionString="mongodb://localhost:27017"
$env:MongoDb__DatabaseName="SecureCodeAI"
```

## React

```powershell
cd frontend
npm install
npm run dev
```

Open:

http://localhost:5173

## API URL examples

Direct OpenAPI:

```text
https://api.example.com/swagger/v1/swagger.json
```

Swagger UI:

```text
https://api.example.com/swagger/index.html
```

Base API:

```text
https://api.example.com
```

The backend tries common Swagger/OpenAPI locations when the entered URL is a base application URL.

## Authentication

For protected APIs, add an optional bearer token in the React UI.

The token is used only for the scan request and is not persisted in MongoDB.

For production:
- never log Authorization headers
- use HTTPS only
- encrypt secrets at rest if persisted
- restrict scanner targets to approved domains
- block SSRF/private-network access unless explicitly allow-listed
- add authentication to the SecureCode AI API itself

## Architecture

React
  |
  | API URL + optional Bearer token
  v
.NET 8 Web API
  |
  +--> Swagger/OpenAPI discovery
  |
  +--> OpenAPI analyzer
  |
  +--> Passive HTTP analyzer
  |
  +--> MongoDB
  |
  v
Security dashboard

## Future production architecture

API URL
  |
  v
API Gateway / Scanner
  |
  +--> OpenAPI Analyzer
  +--> HTTP Passive Analyzer
  +--> Auth Analyzer
  +--> Dependency/CVE source
  +--> Repository/CI connector
  |
  v
AI Security Reasoning
  |
  v
Risk + Remediation
