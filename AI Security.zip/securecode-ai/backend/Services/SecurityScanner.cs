using System.Text.RegularExpressions;
using SecureCodeAI.Api.Models;

namespace SecureCodeAI.Api.Services;

public sealed class SecurityScanner
{
    private sealed record Rule(
        string Id,
        string RuleName,
        string Title,
        Severity Severity,
        string Cwe,
        string Owasp,
        Regex Pattern,
        string Description,
        string Recommendation,
        bool AutoFix);

    private readonly List<Rule> _rules =
    [
        new(
            "SEC001",
            "SQL_INJECTION",
            "Potential SQL Injection",
            Severity.Critical,
            "CWE-89",
            "A03:2021 Injection",
            new Regex(@"(FromSqlRaw|ExecuteSqlRaw)\s*\(\s*\$?""[^""]*(\{[^}]+\}|""\s*\+)", RegexOptions.Compiled),
            "SQL text appears to be constructed using string interpolation or concatenation.",
            "Use parameterized queries or FromSqlInterpolated with strongly typed parameters.",
            true),

        new(
            "SEC002",
            "HARDCODED_SECRET",
            "Potential Hardcoded Secret",
            Severity.High,
            "CWE-798",
            "A07:2021 Identification and Authentication Failures",
            new Regex(@"(?i)\b(api[_-]?key|secret|password|client[_-]?secret)\b\s*[:=]\s*[""'][^""']{6,}[""']", RegexOptions.Compiled),
            "A credential-like value appears to be embedded directly in source code.",
            "Move secrets to environment variables, Azure Key Vault, user secrets, or another secret manager.",
            true),

        new(
            "SEC003",
            "WEAK_CRYPTO",
            "Weak Cryptographic Algorithm",
            Severity.High,
            "CWE-327",
            "A02:2021 Cryptographic Failures",
            new Regex(@"(?i)\b(MD5|SHA1|DES|TripleDES)\b", RegexOptions.Compiled),
            "A deprecated or weak cryptographic algorithm is referenced.",
            "Use SHA-256/SHA-512 for hashing where appropriate, or modern authenticated encryption such as AES-GCM for encryption.",
            false),

        new(
            "SEC004",
            "PATH_TRAVERSAL",
            "Potential Path Traversal",
            Severity.High,
            "CWE-22",
            "A01:2021 Broken Access Control",
            new Regex(@"(?i)\b(File\.(ReadAllText|WriteAllText|Open|Delete|Exists)|FileStream)\s*\([^;\n]*(Request|Query|Form|Route|user|path|fileName)", RegexOptions.Compiled),
            "A filesystem operation appears to consume user-controlled input.",
            "Canonicalize the path and enforce that the resolved path remains inside an approved directory.",
            false),

        new(
            "SEC005",
            "COMMAND_INJECTION",
            "Potential OS Command Injection",
            Severity.Critical,
            "CWE-78",
            "A03:2021 Injection",
            new Regex(@"(?i)(ProcessStartInfo|Process\.Start)\s*\([^;\n]*(Request|Query|Form|user|input)", RegexOptions.Compiled),
            "A process execution API appears to use request or user-controlled data.",
            "Avoid shell execution. If unavoidable, use a strict allow-list of executable names and arguments.",
            false),

        new(
            "SEC006",
            "SENSITIVE_LOGGING",
            "Potential Sensitive Data Logging",
            Severity.Medium,
            "CWE-532",
            "A09:2021 Security Logging and Monitoring Failures",
            new Regex(@"(?i)(Log(Information|Warning|Error|Debug)|Console\.WriteLine)\s*\([^;\n]*(password|token|secret|authorization)", RegexOptions.Compiled),
            "A log statement appears to include credentials, tokens, or authorization data.",
            "Remove sensitive values from logs and use structured logging with explicit safe fields.",
            false),

        new(
            "SEC007",
            "UNSAFE_DESERIALIZATION",
            "Potential Unsafe Deserialization",
            Severity.Critical,
            "CWE-502",
            "A08:2021 Software and Data Integrity Failures",
            new Regex(@"(?i)(BinaryFormatter|TypeNameHandling\s*=\s*TypeNameHandling\.All|JavaScriptSerializer)", RegexOptions.Compiled),
            "A dangerous or historically unsafe deserialization mechanism is referenced.",
            "Use a safe serializer configuration and avoid polymorphic type metadata from untrusted input.",
            false)
    ];

    public ScanResult Scan(string projectName, Dictionary<string, string> files)
    {
        var findings = new List<Finding>();

        foreach (var file in files)
        {
            if (!file.Key.EndsWith(".cs", StringComparison.OrdinalIgnoreCase))
                continue;

            var lines = file.Value.Replace("\r\n", "\n").Split('\n');

            for (var i = 0; i < lines.Length; i++)
            {
                foreach (var rule in _rules)
                {
                    if (!rule.Pattern.IsMatch(lines[i]))
                        continue;

                    findings.Add(new Finding(
                        Guid.NewGuid().ToString("N"),
                        file.Key,
                        i + 1,
                        rule.RuleName,
                        rule.Title,
                        rule.Severity,
                        rule.Cwe,
                        rule.Owasp,
                        rule.Description,
                        lines[i].Trim(),
                        rule.Recommendation,
                        rule.AutoFix));
                }
            }

            ScanControllerAuthorization(file.Key, lines, findings);
        }

        return new ScanResult(
            Guid.NewGuid().ToString("N"),
            projectName,
            DateTime.UtcNow,
            files.Count(x => x.Key.EndsWith(".cs", StringComparison.OrdinalIgnoreCase)),
            findings,
            CalculateScore(findings));
    }

    private static void ScanControllerAuthorization(
        string file,
        string[] lines,
        List<Finding> findings)
    {
        if (!file.EndsWith("Controller.cs", StringComparison.OrdinalIgnoreCase))
            return;

        var controllerDetected = false;
        var authorizeDetected = false;

        for (var i = 0; i < lines.Length; i++)
        {
            if (lines[i].Contains("Controller", StringComparison.Ordinal))
                controllerDetected = true;

            if (lines[i].Contains("[Authorize", StringComparison.OrdinalIgnoreCase))
                authorizeDetected = true;

            if (!controllerDetected || authorizeDetected)
                continue;

            if (Regex.IsMatch(lines[i], @"\b(public|private|protected)\s+(async\s+)?(Task<)?IActionResult\b"))
            {
                findings.Add(new Finding(
                    Guid.NewGuid().ToString("N"),
                    file,
                    i + 1,
                    "MISSING_AUTHORIZATION",
                    "Potential Missing Authorization",
                    Severity.High,
                    "CWE-862",
                    "A01:2021 Broken Access Control",
                    "A controller action appears to be exposed without an authorization attribute.",
                    lines[i].Trim(),
                    "Review the endpoint and add [Authorize] or a suitable policy if the endpoint requires authentication.",
                    false));
            }
        }
    }

    public static int CalculateSecurityScore(List<Finding> findings)
    {
        var deductions = findings.Sum(f => f.Severity switch
        {
            Severity.Critical => 20,
            Severity.High => 10,
            Severity.Medium => 5,
            _ => 2
        });

        return Math.Max(0, 100 - deductions);
    }
}
