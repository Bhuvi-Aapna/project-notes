using Microsoft.Extensions.Options;
using MongoDB.Driver;
using SecureCodeAI.Api.Models;
using SecureCodeAI.Api.Options;

namespace SecureCodeAI.Api.Services;

public sealed class MongoDbService
{
    private readonly IMongoCollection<ScanResult> _scans;

    public MongoDbService(IOptions<MongoDbOptions> options)
    {
        var client = new MongoClient(options.Value.ConnectionString);
        var database = client.GetDatabase(options.Value.DatabaseName);

        _scans = database.GetCollection<ScanResult>("scans");

        _scans.Indexes.CreateOne(
            new CreateIndexModel<ScanResult>(
                Builders<ScanResult>.IndexKeys
                    .Descending(x => x.CreatedAtUtc)));
    }

    public Task SaveAsync(ScanResult scan, CancellationToken ct) =>
        _scans.InsertOneAsync(scan, cancellationToken: ct);

    public Task<ScanResult?> GetAsync(string id, CancellationToken ct) =>
        _scans.Find(x => x.Id == id).FirstOrDefaultAsync(ct);

    public Task<List<ScanResult>> RecentAsync(
        int limit,
        CancellationToken ct) =>
        _scans.Find(_ => true)
            .SortByDescending(x => x.CreatedAtUtc)
            .Limit(Math.Clamp(limit, 1, 100))
            .ToListAsync(ct);
}
