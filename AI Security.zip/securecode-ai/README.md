# SecureCode AI - .NET Security Review & AI Remediation MVP

A working MVP for the AI Arena 2026 idea:

**AI-Powered Secure Code Review & Vulnerability Remediation Engine for .NET Applications**

## Stack

- Backend: ASP.NET Core 8 Web API
- Scanner: C# rule engine + Roslyn-inspired source scanning
- Frontend: React + TypeScript + Vite
- AI: OpenAI-compatible HTTP API (optional; rule-based remediation works without an API key)
- Storage: in-memory for the MVP
- Upload: ZIP containing a .NET source project

## Features

1. Upload a `.zip` .NET project.
2. Scan C# files for:
   - SQL Injection
   - Hardcoded Secrets
   - Weak Cryptography
   - Path Traversal
   - Command Injection
   - Missing Authorization on controller actions
   - Sensitive logging
   - Dangerous deserialization
3. Show severity, CWE, OWASP category, line number and evidence.
4. Generate a remediation using deterministic fixes for common findings.
5. Optionally use an OpenAI-compatible LLM for explanation/remediation.
6. Re-scan after remediation.
7. Calculate a security score.

## Run backend

```bash
cd backend
dotnet restore
dotnet run
```

API:
`http://localhost:5080`

Swagger:
`http://localhost:5080/swagger`

Optional AI environment variables:

```powershell
$env:AI_BASE_URL="https://api.openai.com/v1"
$env:AI_API_KEY="YOUR_KEY"
$env:AI_MODEL="gpt-4o-mini"
```

The application still works without these variables.

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

Open:
`http://localhost:5173`

## Test project

A vulnerable sample project is included under:

`sample-vulnerable-dotnet`

Create ZIP:

```powershell
Compress-Archive -Path .\sample-vulnerable-dotnet\* -DestinationPath .\sample-vulnerable-dotnet.zip
```

Then upload it from the dashboard.

## Production roadmap

Replace the MVP scanner with:
- Microsoft.CodeAnalysis/Roslyn semantic analysis
- NuGet vulnerability auditing
- secret scanning
- dependency CVE service
- GitHub/Azure DevOps PR integration
- persistent SQL Server storage
- queue/worker architecture
- authenticated multi-tenant API
- sandboxed validation builds
