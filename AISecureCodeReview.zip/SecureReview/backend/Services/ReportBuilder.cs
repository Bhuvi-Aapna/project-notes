using SecureReview.Api.Models;

namespace SecureReview.Api.Services;

public static class ReportBuilder
{
    private static readonly Dictionary<string, int> Weight = new()
    {
        ["Critical"] = 25, ["High"] = 15, ["Medium"] = 8, ["Low"] = 3, ["Info"] = 0, ["None"] = 0
    };

    public static ReviewReport Build(string type, string target, List<TestResult> results, bool aiUsed)
    {
        foreach (var r in results) r.OwaspName = OwaspCatalog.NameOf(r.Owasp);

        var counts = new SeverityCounts();
        foreach (var r in results.Where(x => x.Status is "Fail" or "Warning"))
        {
            switch (r.Severity)
            {
                case "Critical": counts.Critical++; break;
                case "High": counts.High++; break;
                case "Medium": counts.Medium++; break;
                case "Low": counts.Low++; break;
                default: counts.Info++; break;
            }
        }

        // Score: 100 minus weighted penalties. Warnings count half. Each rule is capped so one noisy rule can't zero the score.
        var penalty = results
            .Where(x => x.Status is "Fail" or "Warning")
            .GroupBy(x => x.RuleId)
            .Sum(g => Math.Min(30, g.Sum(x =>
                (Weight.TryGetValue(x.Severity, out var w) ? w : 0) / (x.Status == "Warning" ? 2 : 1))));
        var score = Math.Max(0, 100 - penalty);

        var categories = OwaspCatalog.Top10.Select(c =>
        {
            var items = results.Where(r => r.Owasp == c.Id && r.Status != "Info").ToList();
            var failed = items.Count(r => r.Status == "Fail");
            var warn = items.Count(r => r.Status == "Warning");
            return new CategorySummary
            {
                Owasp = c.Id,
                Name = c.Name,
                Tests = items.Count,
                Passed = items.Count(r => r.Status == "Pass"),
                Failed = failed,
                Warnings = warn,
                Status = items.Count == 0 ? "NotTested" : failed > 0 ? "Fail" : warn > 0 ? "Warning" : "Pass"
            };
        }).ToList();

        var executed = results.Count(r => r.Status != "Info");
        return new ReviewReport
        {
            Type = type,
            Target = target,
            CreatedAt = DateTime.UtcNow,
            Score = score,
            Grade = score >= 90 ? "A" : score >= 80 ? "B" : score >= 70 ? "C" : score >= 50 ? "D" : "F",
            Summary = $"{executed} tests run: {results.Count(r => r.Status == "Fail")} failed, " +
                      $"{results.Count(r => r.Status == "Warning")} warnings, {results.Count(r => r.Status == "Pass")} passed.",
            AiUsed = aiUsed,
            Counts = counts,
            Categories = categories,
            Results = results
                .OrderBy(r => r.Status switch { "Fail" => 0, "Warning" => 1, "Info" => 2, _ => 3 })
                .ThenBy(r => Array.IndexOf(new[] { "Critical", "High", "Medium", "Low", "Info", "None" }, r.Severity))
                .ThenBy(r => r.Owasp)
                .ToList()
        };
    }
}
