using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace VulnerableApi.Controllers;

[ApiController]
[Route("api/users")]
public class UserController : ControllerBase
{
    private readonly AppDbContext _db;

    public UserController(AppDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> Get(string username)
    {
        var query = $"SELECT * FROM Users WHERE Username = '{username}'";

        var user = await _db.Users
            .FromSqlRaw(query)
            .FirstOrDefaultAsync();

        return Ok(user);
    }

    [HttpGet("secret")]
    public IActionResult Secret()
    {
        var apiKey = "super-secret-demo-key-123456";
        Console.WriteLine($"token={apiKey}");
        return Ok();
    }
}
