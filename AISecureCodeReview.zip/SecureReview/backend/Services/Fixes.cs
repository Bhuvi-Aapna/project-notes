namespace SecureReview.Api.Services;

/// <summary>Secure code examples attached to rule findings.</summary>
internal static class Fixes
{
    public const string AC001 = """
[Authorize]                      // deny by default
[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    [AllowAnonymous]             // opt-in only for truly public endpoints
    [HttpGet("health")]
    public IActionResult Health() => Ok();

    [Authorize(Roles = "Admin")] // least privilege for sensitive actions
    [HttpDelete("{id}")]
    public IActionResult Delete(string id) => NoContent();
}
""";

    public const string AC002 = """
if (!Url.IsLocalUrl(returnUrl))
    return BadRequest("Invalid return URL.");
return LocalRedirect(returnUrl);
""";

    public const string AC003 = """
var root = Path.GetFullPath(uploadRoot);
var safeName = Path.GetFileName(fileName);               // strips ../ segments
var full = Path.GetFullPath(Path.Combine(root, safeName));
if (!full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.Ordinal))
    return BadRequest("Invalid path.");
var text = await System.IO.File.ReadAllTextAsync(full);
""";

    public const string AC004 = """
builder.Services.AddCors(o => o.AddPolicy("Frontend", p => p
    .WithOrigins("https://app.example.com")   // explicit allow-list
    .WithMethods("GET", "POST")
    .WithHeaders("Content-Type", "Authorization")));
app.UseCors("Frontend");
""";

    public const string CR001 = """
// Hashing data: SHA-256 or better
var hash = SHA256.HashData(Encoding.UTF8.GetBytes(input));

// Passwords: never a plain hash. Use ASP.NET Core Identity's hasher (PBKDF2) or BCrypt/Argon2.
var hasher = new PasswordHasher<User>();
var stored = hasher.HashPassword(user, password);
var ok = hasher.VerifyHashedPassword(user, stored, attempt) != PasswordVerificationResult.Failed;
""";

    public const string CR002 = """
using var aes = new AesGcm(key, tagSizeInBytes: 16);     // authenticated encryption, 256-bit key
var nonce = RandomNumberGenerator.GetBytes(12);          // unique per message
var cipher = new byte[plain.Length];
var tag = new byte[16];
aes.Encrypt(nonce, plain, cipher, tag);
// store nonce + cipher + tag; keep the key in Azure Key Vault
""";

    public const string CR003 = """
// appsettings.json holds no secrets. Locally use user-secrets, in Azure use Key Vault.
builder.Configuration.AddAzureKeyVault(
    new Uri("https://<your-vault>.vault.azure.net/"),
    new DefaultAzureCredential());

var apiKey = builder.Configuration["Payments:ApiKey"]
    ?? throw new InvalidOperationException("Payments:ApiKey is not configured.");
// Rotate any secret that was ever committed to source control.
""";

    public const string CR004 = """
var bytes = RandomNumberGenerator.GetBytes(32);
var token = Convert.ToBase64String(bytes);               // cryptographically secure
var n = RandomNumberGenerator.GetInt32(100000, 999999);  // secure numeric code
""";

    public const string CR005 = """
// Remove the custom validation callback entirely. The default validates the chain and host name.
builder.Services.AddHttpClient("partner");
// For a private CA, trust that CA explicitly instead of accepting every certificate.
""";

    public const string CR006 = """
var client = new HttpClient { BaseAddress = new Uri("https://api.example.com/") };
// and enforce HTTPS + HSTS for your own app:
app.UseHttpsRedirection();
app.UseHsts();
""";

    public const string IN001 = """
// ADO.NET: parameters
using var cmd = new SqlCommand("SELECT * FROM Users WHERE Email = @email", conn);
cmd.Parameters.Add("@email", SqlDbType.NVarChar, 256).Value = email;

// EF Core: interpolated overloads parameterise automatically
var users = await db.Users.FromSqlInterpolated($"SELECT * FROM Users WHERE Email = {email}").ToListAsync();
""";

    public const string IN002 = """
// Use typed builders: user input is always a value, never part of the query text.
var filter = Builders<User>.Filter.And(
    Builders<User>.Filter.Eq(u => u.Email, email),
    Builders<User>.Filter.Eq(u => u.IsActive, true));
var user = await users.Find(filter).FirstOrDefaultAsync();

// Never use $where / BsonJavaScript with request data.
// Bind JSON bodies to strongly typed DTOs; reject operators such as "$ne" in string fields.
""";

    public const string IN003 = """
// Prefer a managed API over a shell. If a process is unavoidable, no shell and an allow-list:
var allowed = new HashSet<string> { "pdf", "png" };
if (!allowed.Contains(format)) return BadRequest();
var psi = new ProcessStartInfo("convert") { UseShellExecute = false, RedirectStandardOutput = true };
psi.ArgumentList.Add(inputPath);          // each argument separate, never a concatenated string
psi.ArgumentList.Add($"out.{format}");
using var p = Process.Start(psi)!;
""";

    public const string IN004 = """
@* Razor encodes by default: *@
<p>@Model.Comment</p>

// If HTML must be shown, sanitise on the server first (HtmlSanitizer package):
var sanitizer = new HtmlSanitizer();
var safe = sanitizer.Sanitize(userHtml);
""";

    public const string IN005 = """
// React: render text, not HTML. JSX escapes values automatically.
<p>{comment}</p>

// If rich text is unavoidable, sanitise first:
import DOMPurify from "dompurify";
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(html) }} />

// Replace eval / new Function with JSON.parse or a lookup table.
""";

    public const string DS001 = """
builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    o.AddFixedWindowLimiter("auth", c => { c.PermitLimit = 5; c.Window = TimeSpan.FromMinutes(1); c.QueueLimit = 0; });
});
app.UseRateLimiter();

[EnableRateLimiting("auth")]
[HttpPost("login")]
public async Task<IActionResult> Login(LoginRequest req) { /* ... */ }
""";

    public const string DS002 = """
private static readonly string[] Allowed = { ".png", ".jpg", ".pdf" };
const long MaxBytes = 5 * 1024 * 1024;

if (file.Length is 0 or > MaxBytes) return BadRequest("Invalid size.");
var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
if (!Allowed.Contains(ext)) return BadRequest("File type not allowed.");
var storedName = $"{Guid.NewGuid():N}{ext}";            // never trust the client file name
// Store outside the web root and scan with antivirus where possible.
""";

    public const string MC001 = """
if (app.Environment.IsDevelopment())
    app.UseDeveloperExceptionPage();
else
    app.UseExceptionHandler("/error");
""";

    public const string MC002 = """
if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
}
app.UseHttpsRedirection();
""";

    public const string MC003 = """
builder.Services.AddHsts(o => { o.MaxAge = TimeSpan.FromDays(365); o.IncludeSubDomains = true; });
if (!app.Environment.IsDevelopment()) app.UseHsts();
""";

    public const string MC004 = """
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
""";

    public const string MC005 = """
catch (Exception ex)
{
    _logger.LogError(ex, "Order creation failed");               // details stay in the log
    return Problem(title: "Unexpected error", statusCode: 500);  // generic message to the client
}
""";

    public const string MC006 = """
var settings = new XmlReaderSettings
{
    DtdProcessing = DtdProcessing.Prohibit,
    XmlResolver = null
};
using var reader = XmlReader.Create(stream, settings);
var doc = new XmlDocument { XmlResolver = null };
doc.Load(reader);
""";

    public const string MC007 = """
app.Use(async (ctx, next) =>
{
    var h = ctx.Response.Headers;
    h["X-Content-Type-Options"] = "nosniff";
    h["X-Frame-Options"] = "DENY";
    h["Referrer-Policy"] = "no-referrer";
    h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
    h["Content-Security-Policy"] = "default-src 'self'; frame-ancestors 'none'";
    await next();
});
""";

    public const string MC008 = """
// Keep antiforgery on for cookie-authenticated endpoints.
builder.Services.AddControllersWithViews(o => o.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()));
// Pure token (Bearer) APIs are not CSRF-prone, but cookie-based ones are.
""";

    public const string MC009 = """
{
  "Logging": { "LogLevel": { "Default": "Information" } },
  "AllowedHosts": "api.example.com",
  "DetailedErrors": false
}
""";

    public const string VC001 = """
dotnet list package --vulnerable --include-transitive
dotnet add package Newtonsoft.Json --version 13.0.3
dotnet add package log4net --version 2.0.17
// Enable Dependabot / GitHub dependency review in CI and fail the build on high severity advisories.
""";

    public const string VC002 = """
npm audit --omit=dev
npm install lodash@latest axios@latest
// Commit package-lock.json and run `npm ci` in CI.
""";

    public const string AU001 = """
options.TokenValidationParameters = new TokenValidationParameters
{
    ValidateIssuer = true,
    ValidIssuer = cfg["Jwt:Issuer"],
    ValidateAudience = true,
    ValidAudience = cfg["Jwt:Audience"],
    ValidateLifetime = true,
    ValidateIssuerSigningKey = true,
    IssuerSigningKey = new SymmetricSecurityKey(Convert.FromBase64String(cfg["Jwt:Key"]!)),
    ClockSkew = TimeSpan.FromMinutes(1)
};
""";

    public const string AU002 = """
// Load a 256-bit+ random key from Key Vault / environment, never from source code.
var keyBytes = Convert.FromBase64String(builder.Configuration["Jwt:Key"]
    ?? throw new InvalidOperationException("Jwt:Key missing"));
var signingKey = new SymmetricSecurityKey(keyBytes);
""";

    public const string AU003 = """
builder.Services.Configure<IdentityOptions>(o =>
{
    o.Password.RequiredLength = 12;
    o.Password.RequireDigit = true;
    o.Lockout.MaxFailedAccessAttempts = 5;
    o.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
});
""";

    public const string AU004 = """
var hasher = new PasswordHasher<User>();
var result = hasher.VerifyHashedPassword(user, user.PasswordHash, model.Password);
if (result == PasswordVerificationResult.Failed) return Unauthorized();
""";

    public const string AU005 = """
options.Cookie.HttpOnly = true;
options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
options.Cookie.SameSite = SameSiteMode.Strict;
""";

    public const string AU006 = """
// Best: keep the token in an HttpOnly + Secure + SameSite cookie set by the API,
// then call the API with credentials:
fetch("/api/orders", { credentials: "include" });
// If a header token is required, hold it in memory only (React state), not in localStorage.
""";

    public const string AU007 = """
var result = await signInManager.PasswordSignInAsync(
    model.Email, model.Password, model.RememberMe, lockoutOnFailure: true);
if (result.IsLockedOut) return StatusCode(423, "Account temporarily locked.");
""";

    public const string SI001 = """
// Use System.Text.Json with typed models. Never deserialise to arbitrary types.
var order = JsonSerializer.Deserialize<OrderDto>(json);

// Newtonsoft: keep the safe default
var settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.None };
// BinaryFormatter is removed from modern .NET. Do not re-enable it.
""";

    public const string SI002 = """
<script src="https://cdn.example.com/lib@1.2.3/lib.min.js"
        integrity="sha384-<hash-from-your-build>"
        crossorigin="anonymous"></script>
<!-- or bundle the dependency with Vite and serve it from your own origin -->
""";

    public const string SI003 = """
// Load only known plugins from a trusted folder and verify the signature/hash first.
var allowed = new HashSet<string> { "Reports.dll", "Exports.dll" };
if (!allowed.Contains(Path.GetFileName(name))) return BadRequest();
var asm = Assembly.LoadFrom(Path.Combine(pluginRoot, name));
""";

    public const string LG001 = """
_logger.LogInformation("Login attempt for user {UserId}", user.Id);   // identifiers only
// Never log passwords, tokens, secrets, card numbers or full request bodies.
""";

    public const string LG002 = """
catch (Exception ex)
{
    _logger.LogWarning(ex, "Payment webhook failed for {OrderId}", orderId);
    throw;        // or handle deliberately: never swallow silently
}
""";

    public const string LG003 = """
_logger.LogInformation("Login success for {UserId} from {Ip}", user.Id, HttpContext.Connection.RemoteIpAddress);
_logger.LogWarning("Login failure for {Email} from {Ip}", email, HttpContext.Connection.RemoteIpAddress);
// Send these to Azure Monitor / Application Insights and alert on spikes of failures.
""";

    public const string SR001 = """
private static readonly HashSet<string> AllowedHosts = new(StringComparer.OrdinalIgnoreCase) { "api.partner.com" };

if (!Uri.TryCreate(input, UriKind.Absolute, out var uri) || uri.Scheme != Uri.UriSchemeHttps
    || !AllowedHosts.Contains(uri.Host))
    return BadRequest("Host not allowed.");

// Also block private ranges after DNS resolution (127.0.0.0/8, 10/8, 172.16/12, 192.168/16, 169.254.169.254)
// and disable auto-redirects on the HttpClient handler.
var res = await _http.GetAsync(uri);
""";

    // ---- URL scan fixes -------------------------------------------------------------------

    public const string U_Https = """
app.UseHttpsRedirection();
app.UseHsts();     // production only
""";

    public const string U_Hsts = """
builder.Services.AddHsts(o => { o.MaxAge = TimeSpan.FromDays(365); o.IncludeSubDomains = true; o.Preload = true; });
app.UseHsts();
""";

    public const string U_Csp = """
app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["Content-Security-Policy"] =
        "default-src 'self'; script-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'";
    await next();
});
""";

    public const string U_Headers = """
app.Use(async (ctx, next) =>
{
    var h = ctx.Response.Headers;
    h["X-Content-Type-Options"] = "nosniff";
    h["X-Frame-Options"] = "DENY";
    h["Referrer-Policy"] = "strict-origin-when-cross-origin";
    h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
    await next();
});
""";

    public const string U_Banner = """
builder.WebHost.ConfigureKestrel(o => o.AddServerHeader = false);
// IIS web.config:
// <system.webServer><security><requestFiltering removeServerHeader="true" /></security>
//   <httpProtocol><customHeaders><remove name="X-Powered-By" /></customHeaders></httpProtocol></system.webServer>
""";

    public const string U_Cookie = """
builder.Services.ConfigureApplicationCookie(o =>
{
    o.Cookie.HttpOnly = true;
    o.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    o.Cookie.SameSite = SameSiteMode.Strict;
});
// Manual cookies:
Response.Cookies.Append("sid", value, new CookieOptions { HttpOnly = true, Secure = true, SameSite = SameSiteMode.Strict });
""";

    public const string U_Error = """
if (app.Environment.IsDevelopment()) app.UseDeveloperExceptionPage();
else app.UseExceptionHandler(a => a.Run(async ctx =>
{
    ctx.Response.StatusCode = 500;
    await ctx.Response.WriteAsJsonAsync(new { error = "Unexpected server error." });
}));
""";

    public const string U_Files = """
// Never deploy secrets or VCS data into the web root.
// .gitignore + .dockerignore: .env, .git/, appsettings.*.json
// Keep config outside wwwroot; use Key Vault / environment variables for secrets; rotate anything exposed.
// nginx: location ~ /\.(?!well-known) { deny all; }
""";

    public const string U_Swagger = """
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
""";

    public const string U_Methods = """
// nginx: if ($request_method ~ ^(TRACE|TRACK)$) { return 405; }
// IIS: Request Filtering > HTTP Verbs > Deny TRACE
app.Use(async (ctx, next) =>
{
    if (HttpMethods.IsTrace(ctx.Request.Method)) { ctx.Response.StatusCode = 405; return; }
    await next();
});
""";

    public const string U_Cors = """
builder.Services.AddCors(o => o.AddPolicy("Frontend", p => p
    .WithOrigins("https://app.example.com")
    .WithMethods("GET", "POST")
    .WithHeaders("Content-Type", "Authorization")));
app.UseCors("Frontend");
// Never combine AllowCredentials() with a wildcard or reflected origin.
""";

    public const string U_Auth = """
[Authorize]
[ApiController]
public class DataController : ControllerBase { /* ... */ }
// builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(...);
""";

    public const string U_Reflect = """
// Razor / React encode output by default; never write request values into HTML with Html.Raw / innerHTML.
// Add a Content-Security-Policy as a second line of defence, and return generic errors (no SQL/driver text).
""";

    public const string U_Sri = """
<script src="https://cdn.example.com/lib.js" integrity="sha384-<hash>" crossorigin="anonymous"></script>
""";

    public const string U_Cache = """
app.Use(async (ctx, next) =>
{
    if (ctx.Request.Path.StartsWithSegments("/api"))
        ctx.Response.Headers.CacheControl = "no-store";
    await next();
});
""";

    public const string U_RateLimit = """
builder.Services.AddRateLimiter(o => o.AddFixedWindowLimiter("api", c =>
{ c.PermitLimit = 100; c.Window = TimeSpan.FromMinutes(1); c.QueueLimit = 0; }));
app.UseRateLimiter();
app.MapControllers().RequireRateLimiting("api");
""";

    public const string U_Components = """
// Upgrade the runtime/web server, then hide version banners.
// .NET: dotnet --list-runtimes   (stay on a supported LTS: .NET 8 or newer)
// Run `dotnet list package --vulnerable` and `npm audit` in CI.
""";
}
