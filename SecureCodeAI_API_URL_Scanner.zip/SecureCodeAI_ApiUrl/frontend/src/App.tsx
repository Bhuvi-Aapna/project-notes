import { useState } from "react";

type Finding = {
  id: string;
  source: string;
  rule: string;
  title: string;
  severity: "Low" | "Medium" | "High" | "Critical";
  cwe: string;
  owasp: string;
  endpoint: string;
  method: string;
  description: string;
  evidence: string;
  recommendation: string;
};

type ScanResult = {
  id: string;
  targetUrl: string;
  swaggerUrl: string;
  createdAtUtc: string;
  securityScore: number;
  endpointsAnalyzed: number;
  findings: Finding[];
  severityCounts: Record<string, number>;
  liveChecks: Record<string, string>;
};

export default function App() {
  const [apiUrl, setApiUrl] = useState("");
  const [token, setToken] = useState("");
  const [scan, setScan] = useState<ScanResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function scanApi() {
    if (!apiUrl.trim()) return;

    setLoading(true);
    setError("");
    setScan(null);

    try {
      const response = await fetch("/api/scans/url", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          apiUrl: apiUrl.trim(),
          bearerToken: token.trim() || null
        })
      });

      const data = await response.json();

      if (!response.ok)
        throw new Error(data.message || "Scan failed.");

      setScan(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Scan failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="app">
      <header>
        <div>
          <div className="logo">SECURECODE <span>AI</span></div>
          <div className="tagline">
            API URL • Swagger/OpenAPI • Security Intelligence
          </div>
        </div>
        <div className="arena">AI ARENA 2026</div>
      </header>

      <main>
        <section className="hero">
          <div>
            <h1>Scan your API.</h1>
            <p>
              Enter an authorized application API URL. SecureCode AI discovers
              Swagger/OpenAPI, analyzes the API contract and performs passive
              HTTP security checks.
            </p>
          </div>

          <div className="scanner-card">
            <label>Application API URL</label>

            <input
              value={apiUrl}
              onChange={e => setApiUrl(e.target.value)}
              placeholder="https://api.example.com"
            />

            <label>
              Bearer Token <span>(optional)</span>
            </label>

            <input
              type="password"
              value={token}
              onChange={e => setToken(e.target.value)}
              placeholder="eyJhbGciOi..."
            />

            <small>
              Token is sent to the scanner only and is not stored in MongoDB.
            </small>

            <button
              disabled={!apiUrl.trim() || loading}
              onClick={scanApi}
            >
              {loading ? "Scanning API..." : "Start Security Scan"}
            </button>
          </div>
        </section>

        {error && <div className="error">{error}</div>}

        {scan && (
          <>
            <section className="target">
              <div>
                <span>Target</span>
                <strong>{scan.targetUrl}</strong>
              </div>

              <div>
                <span>Swagger</span>
                <strong>
                  {scan.swaggerUrl || "Not discovered"}
                </strong>
              </div>

              <div>
                <span>Endpoints</span>
                <strong>{scan.endpointsAnalyzed}</strong>
              </div>
            </section>

            <section className="stats">
              <div className="score">
                <span>Security Score</span>
                <strong>{scan.securityScore}</strong>
                <small>/100</small>
              </div>

              <Stat
                label="Critical"
                value={scan.severityCounts.Critical ?? 0}
              />

              <Stat
                label="High"
                value={scan.severityCounts.High ?? 0}
              />

              <Stat
                label="Medium"
                value={scan.severityCounts.Medium ?? 0}
              />

              <Stat
                label="Low"
                value={scan.severityCounts.Low ?? 0}
              />
            </section>

            <section className="panel">
              <div className="panel-head">
                <div>
                  <h2>Vulnerability Findings</h2>
                  <p>
                    {scan.findings.length} findings identified
                  </p>
                </div>
              </div>

              {scan.findings.length === 0 ? (
                <div className="success">
                  No findings were detected by the current passive rules.
                </div>
              ) : (
                scan.findings.map(finding => (
                  <article className="finding" key={finding.id}>
                    <div className={`severity ${finding.severity.toLowerCase()}`}>
                      {finding.severity}
                    </div>

                    <div>
                      <div className="title-row">
                        <h3>{finding.title}</h3>
                        <span>{finding.source}</span>
                      </div>

                      <div className="meta">
                        {finding.method && `${finding.method} `}
                        {finding.endpoint}
                        {" • "}
                        {finding.rule}
                        {" • "}
                        {finding.cwe}
                        {" • "}
                        {finding.owasp}
                      </div>

                      <p>{finding.description}</p>

                      <pre>{finding.evidence}</pre>

                      <div className="recommendation">
                        <b>Remediation:</b>{" "}
                        {finding.recommendation}
                      </div>
                    </div>
                  </article>
                ))
              )}
            </section>

            <section className="panel">
              <h2>Passive HTTP Checks</h2>

              <div className="checks">
                {Object.entries(scan.liveChecks).map(
                  ([key, value]) => (
                    <div className="check" key={key}>
                      <span>{key}</span>
                      <strong>{value}</strong>
                    </div>
                  )
                )}
              </div>
            </section>
          </>
        )}
      </main>
    </div>
  );
}

function Stat({
  label,
  value
}: {
  label: string;
  value: number;
}) {
  return (
    <div className="stat">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
