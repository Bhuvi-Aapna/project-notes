using Microsoft.AspNetCore.Mvc;
using SecureCodeAI.Api.Models;
using SecureCodeAI.Api.Services;

namespace SecureCodeAI.Api.Controllers;

[ApiController]
[Route("api/scans")]
public sealed class ScanController : ControllerBase
{
    private readonly ApiUrlScanner _scanner;
    private readonly MongoDbService _mongo;
    private readonly ILogger<ScanController> _logger;

    public ScanController(
        ApiUrlScanner scanner,
        MongoDbService mongo,
        ILogger<ScanController> logger)
    {
        _scanner = scanner;
        _mongo = mongo;
        _logger = logger;
    }

    [HttpPost("url")]
    public async Task<ActionResult<ScanResult>> ScanUrl(
        [FromBody] ScanUrlRequest request,
        CancellationToken ct)
    {
        if (request is null ||
            string.IsNullOrWhiteSpace(request.ApiUrl))
        {
            return BadRequest(new
            {
                message = "ApiUrl is required."
            });
        }

        try
        {
            _logger.LogInformation(
                "Starting API security scan for {TargetUrl}",
                request.ApiUrl);

            var result = await _scanner.ScanAsync(
                request.ApiUrl,
                request.BearerToken,
                ct);

            await _mongo.SaveAsync(result, ct);

            _logger.LogInformation(
                "Completed scan {ScanId} for {TargetUrl}. Findings: {Count}",
                result.Id,
                result.TargetUrl,
                result.Findings.Count);

            return Ok(result);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new
            {
                message = ex.Message
            });
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Target API request failed.");

            return StatusCode(
                StatusCodes.Status502BadGateway,
                new
                {
                    message = "Unable to reach the target API.",
                    error = ex.Message
                });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "API security scan failed.");

            return StatusCode(
                StatusCodes.Status500InternalServerError,
                new
                {
                    message = "API security scan failed.",
                    error = ex.Message
                });
        }
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ScanResult>> Get(
        string id,
        CancellationToken ct)
    {
        var scan = await _mongo.GetAsync(id, ct);

        return scan is null
            ? NotFound()
            : Ok(scan);
    }

    [HttpGet]
    public async Task<ActionResult<List<ScanResult>>> Recent(
        [FromQuery] int limit = 20,
        CancellationToken ct = default)
    {
        return Ok(await _mongo.RecentAsync(limit, ct));
    }
}

public sealed record ScanUrlRequest(
    string ApiUrl,
    string? BearerToken);
